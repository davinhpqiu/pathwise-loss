# Response constrained Euler storage

30 September 2026. Norms follow `mathematics.md`: Frobenius coefficient tuple,
Hilbert--Schmidt tensors, operator norm response. Decoder and dense generic
log-signature storage follow Ferrucci, Perrée and Lyons (FPL),
`papers/2607.26281v1.pdf`, (1.8)--(1.10). Results below concern Euler decoding.

## 1. Exact bounded variation minimax error

Write $P_N(x)=\sum_{j=0}^N x^j/j!$. For a bounded variation path $X$, a
coefficient tuple $A$ and a partition with $m$ intervals, put

$$
x_i=\lVert A\rVert_F\lVert X\rVert_{1\text{-var};[t_{i-1},t_i]},
\qquad R=\sum_i x_i.
$$

### Theorem

For arbitrary interval lengths,

$$
\lVert\Phi^A(X)-E^A_{N,\pi}(X)\rVert_{\mathrm{op}}
\le e^R-\prod_{i=1}^m P_N(x_i).
$$

For $N,m\ge1$, the exact worst error over paths with
$\lVert A\rVert_F\lVert X\rVert_{1\text{-var}}\le r$, allowing a partition
depending on $X$ and independent of $A$, is

$$
\boxed{\mathcal E(N,m,r)=e^r-P_N(r/m)^m.}
$$

An equal variation partition attains the upper bound. A straight line with a
rank-one scalar development attains the worst error for every response
dimension. Equal variation also minimizes the displayed majorant among
partitions with fixed total variation and interval count.

*Proof.* Expand each exact interval factor into its homogeneous response
series. Its degree $j$ term has operator norm at most $x_i^j/j!$, by
signature factorial decay and FPL (1.9). Expand the product of all exact
factors. The Euler product retains precisely terms with every interval degree
at most $N$. Thus the difference is a sum over excluded multi-indices; absolute
convergence and the triangle inequality give

$$
\sum_{\substack{j_1,\ldots,j_m\ge0\\\max j_i>N}}
\prod_i\frac{x_i^{j_i}}{j_i!}
=e^R-\prod_iP_N(x_i).
$$

This also shows the majorant increases in each $x_i$. To minimize it at fixed
$R$, maximize $\sum_i\log P_N(x_i)$. For $N\ge2$,

$$
P_{N-1}(x)^2-P_N(x)P_{N-2}(x)
=\frac{x^{N-1}}{N!}\sum_{j=0}^{N-1}(N-j)\frac{x^j}{j!}\ge0.
$$

Consequently $\log P_N$ is concave on $[0,\infty)$, strictly concave for
$x>0$. For $N=1$ it equals $\log(1+x)$ and is strictly concave. Jensen gives
$\prod_iP_N(x_i)\le P_N(R/m)^m$.

Choose $X_t=t e_1$ on $[0,1]$, $A_1=rQ$ where $Q$ is an orthogonal rank-one
projection, and $A_i=0$ for $i>1$. The exact response on range $Q$ is $e^r$;
on any partition Euler response is $\prod_iP_N(r\Delta t_i)$. Jensen shows
even the best partition has error at least $e^r-P_N(r/m)^m$. Outside range
$Q$ both responses are identity. This proves the minimax equality, including
the permission to choose partitions adaptively. $\square$

FPL already display this scalar expression as a sharpness example in (1.13).
The extension here is its universal upper bound, partition minimization and
resulting exact discrete constraint. Novelty relative to wider numerical
analysis literature remains unverified.

## 2. Exact discrete optimization and asymptotics

Two sources of conservatism are separate. The exact weighted HS certificate
is the sum of homogeneous error norms; FPL's length envelope applies further
tail/product bounds. Straight lines attain the exact scalar error and its HS
certificate. The BV refinement below improves the length envelope, while the
pure Lie comparison in §3 exhibits a response/HS gap within the specified class.

With Witt dimension

$$
\Lambda_d(N)=\sum_{j=1}^N\frac1j\sum_{h\mid j}\mu(h)d^{j/h},
$$

the bounded variation problem becomes the computable integer optimization

$$
\min_{N,m\in\mathbb N_+}m\Lambda_d(N)
\quad\text{subject to}\quad\mathcal E(N,m,r)\le\varepsilon.
$$

For each $N$, $\mathcal E$ decreases in $m$, by concavity of $\log P_N$ and
$P_N(0)=1$. Bisection gives the smallest feasible $m$. Enumeration stops when
$\Lambda_d(N)$ exceeds the best total storage already found: even $m=1$
then costs more, and $\Lambda_d$ increases. This certifies a global integer
minimum without imposing an arbitrary search cap. Log arithmetic locates a
candidate interval count; close feasibility comparisons are refined with
decimal precision exceeding its number of digits. Arithmetic is numerical,
rather than interval-certified.

### Proposition

Let $C_{d,k}(z,\varepsilon)$ minimize $m\Lambda_d(kq)$ subject to
$\mathcal E(q,m,z)\le\varepsilon$, with integers $q,m\ge1$ and fixed
$d\ge2$, $k\ge1$. Define $\beta=k\log d$ and
$\lambda=z+\log(z/\varepsilon)$. In either limit $z\to\infty$ with
$\varepsilon$ fixed or $\varepsilon\downarrow0$ with $z>0$ fixed,

$$
q_*\sim\sqrt{\lambda/\beta},\qquad
\log(m_*/z)\sim\sqrt{\beta\lambda},\qquad
\log(C_{d,k}/z)\sim2\sqrt{\beta\lambda}.
$$

Replacing $\mathcal E(q,m,z)$ by FPL's bound

$$
B(q,m,z)=\frac{e^z z^{q+1}}{(q+1)!m^q}
$$

changes optimal storage by a relative factor tending to one. Integer optima
can differ at finite parameters. The leading logarithmic formulas above
avoid claiming continuous prefactors for integer optimizers.

*Proof.* Write $x=z/m$ and
$a=e^{-x}\sum_{j=q+1}^\infty x^j/j!$. Then

$$
\mathcal E=e^z[1-(1-a)^m],\qquad
e^{-x}\frac{x^{q+1}}{(q+1)!}\le a
\le\frac{x^{q+1}}{(q+1)!}.
$$

Bernoulli's inequality applied to $(1-a)^{-m}$ yields
$1-(1-a)^m\ge ma/(1+ma)$. Hence

$$
\frac{e^{-x}}{1+ma}\le\frac{\mathcal E}{B}\le1.
$$

If $\mathcal E\le\varepsilon<e^z$, the inequality
$1-(1-a)^m\ge1-e^{-ma}$ gives
$ma\le-\log(1-\varepsilon e^{-z})$.

Taking $q$ nearest $\sqrt{\lambda/\beta}$ and the least integer satisfying
$B\le\varepsilon$ gives
$\log(C_{d,k}/z)\le2\sqrt{\beta\lambda}+O(\log\lambda)$, by Stirling and
FPL Theorem 1.2. In particular any optimizer has $q=O(\sqrt\lambda)$.
Its interval count diverges and $x\to0$: for fixed $z$, a bounded $m$ would
give $\log\mathcal E\ge-O(\sqrt\lambda\log\lambda)$ from the first tail
term, contradicting $\log\varepsilon\sim-\lambda$. For $z\to\infty$, if
$m=1$ then $e^{-z}P_q(z)\to0$ and $\mathcal E\sim e^z$; if $m\ge2$ and
$x\ge c>0$, the first tail term gives
$\log\mathcal E\ge z/2-O(\sqrt z\log z)$, also infeasible. For fixed $z$,
$ma\le z x^q/(q+1)!\le zx/2\to0$ once $x<1$, since $q\ge1$.
For $z\to\infty$ with fixed $\varepsilon$, feasibility gives $ma\to0$
by the displayed logarithmic bound. Thus
$\mathcal E/B\to1$ at every optimizer.

The lower bound above implies
$\log B\le\log\varepsilon+o(1)$. Combining with Witt asymptotics and
Stirling gives, uniformly for optimizing orders,

$$
\log(C_{d,k}/z)
\ge\beta q+\lambda/q-O(\log\lambda).
$$

The minimum of $\beta q+\lambda/q$ is $2\sqrt{\beta\lambda}$; the upper
bound forces $q/\sqrt{\lambda/\beta}\to1$. The formula for $m$ follows by
subtracting $\log\Lambda_d(kq)$ from total storage. Finally inflate $m$ at
an exact optimizer by factor $\max(1,(B/\varepsilon)^{1/q})$, rounding up.
This makes $B\le\varepsilon$ at relative storage cost $1+o(1)$, because
$B/\varepsilon\le1+o(1)$ and $m\to\infty$. Exact and bound constrained
minimal costs therefore have ratio tending to one. $\square$

For $k=1$ this preserves FPL's leading bounded variation asymptotics. Their
universal admissible class contains straight lines, so within-level Lie
response gaps cannot improve that minimax rate.

## 3. Pure Engel paths: rigorous structured storage bounds

Let $E_k=\operatorname{ad}_{e_1}^{k-1}(e_2)$, $k\ge2$, and consider
$\mathbf X_t=\exp_\otimes(t a E_k)$ for $a>0$, a pure degree-$k$ weakly
geometric rough path. Absorb coefficient radius into $a$ by homogeneity:
original amplitude $b$ and radius $r$ give $a=br^k$. Set

$$
h_k=\lVert E_k\rVert_{\mathrm{HS}}
=\sqrt{\binom{2k-2}{k-1}},\qquad
g_k=[2(k-1)]^{(k-1)/2}k^{-k/2},\qquad s_k=g_k/\sqrt2.
$$

For truncation $N=kq$, an equal partition gives Euler response
$P_q(aR_A(E_k)/m)^m$ and exact response $e^{aR_A(E_k)}$, for unit
Frobenius coefficient tuples. Let $\delta_k(q,m,a)$ be their response
supremum, in any response dimension at least two.

### Theorem

$$
\boxed{
\mathcal E(q,m,a s_k)
\le\delta_k(q,m,a)
\le\mathcal E(q,m,a g_k)
<\mathcal E(q,m,a h_k).
}
$$

The last expression is the exact full weighted Hilbert--Schmidt certificate
for this Euler error. The lower bound holds for arbitrary partitions after
minimizing the attained scalar error over those partitions.

*Proof.* Section 2 of `proofs.md` gives
$\lVert R_A(E_k)\rVert_{\mathrm{op}}\le g_k$ uniformly over response
dimension. Expand $e^{aC}-P_q(aC/m)^m$: coefficients of $C^j$ are
nonnegative, since the polynomial product retains a subset of the exponential
product terms. Bounding each $\lVert C^j\rVert\le g_k^j$ gives the upper
bound.

For the lower bound put $\alpha=\sqrt{(k-1)/k}$,
$\eta=1/\sqrt k$ and take

$$
A_1=\frac\alpha{\sqrt2}
\begin{pmatrix}1&0\\0&-1\end{pmatrix},\qquad
A_2=\frac\eta{\sqrt2}
\begin{pmatrix}0&1\\(-1)^{k-1}&0\end{pmatrix}.
$$

Their tuple norm is one, and $R_A(E_k)$ is symmetric with off-diagonal
entries $g_k/\sqrt2$. A unit positive eigenvector gives precisely the scalar
Euler error with scale $a s_k$. Embed this block in larger response dimensions.
The partition lower bound follows from §1's concavity argument.

At tensor degree $kj$, the Euler error is $c_j a^j E_k^{\otimes j}$ with
$c_j\ge0$. Its Hilbert--Schmidt norm is $c_j(a h_k)^j$. Summing gives
$\mathcal E(q,m,a h_k)$ exactly. Since $g_k<h_k$ and $\mathcal E$ is
strictly increasing in its positive scale, the final inequality is strict.
$\square$

Let $C_k^{\mathrm{true}}$ minimize dense generic storage using true response
error and allowing adaptive partitions. For
$\varepsilon<e^{a s_k}-1$, depths below $k$ are infeasible. Intermediate
depths between $kq$ and $k(q+1)$ yield the same Euler polynomial as $kq$, at
larger storage. Thus

$$
\boxed{
C_{d,k}(a s_k,\varepsilon)
\le C_k^{\mathrm{true}}(a,\varepsilon)
\le C_{d,k}(a g_k,\varepsilon)
\le C_{d,k}(a h_k,\varepsilon).
}
$$

The middle computation is a proved feasible representation; its optimum is
an upper bound on the true optimum. An optimum computed from the witness is
a lower bound on true storage, and need not itself be feasible.

### Corollary: growing storage separation

For fixed $k,d,\varepsilon$ and $a\to\infty$,

$$
\liminf_{a\to\infty}\frac1{\sqrt a}
\log\frac{C_{d,k}(a h_k,\varepsilon)}{C_k^{\mathrm{true}}(a,\varepsilon)}
\ge2\sqrt{k\log d}\,(\sqrt{h_k}-\sqrt{g_k})>0.
$$

This follows directly from §2 and the storage sandwich. Thus the loss from
the HS certificate grows at least stretched exponentially with pure-path
amplitude, within FPL's Euler decoding and generic storage convention. For
fixed $a$ and $\varepsilon\downarrow0$, both ends of the sandwich have
leading log storage $2\sqrt{k\log d\log(1/\varepsilon)}$, so that leading
rate is unchanged.

Scope: a single depth-$k$ log-ODE factor represents this pure path exactly.
A decoder exploiting that fact, or storing only its known nonzero Lie
direction, has a different storage problem. These pure paths are an analytic
Euler benchmark; practical compression must extend to changing, noncommuting
Lie directions or mixed degrees. FPL's general rough-path bound in Theorem
2.8 is a separate constraint; the structured comparison here uses the exact
HS certificate of each pure path rather than that general bound.

## 4. Experiment design, recorded before execution

Runner: `scripts/study_response_storage.py`. Shared code:
`src/pathloss/response_storage.py`. The grid uses neither ascent, GPU nor random sampling.

Bounded variation grid: $d\in\{2,3,5\}$,
$r\in\{0.1,0.5,1,2,5,10,20,50,100\}$ and
$\varepsilon\in\{10^{-1},10^{-2},10^{-4},10^{-8},10^{-12}\}$.
For each case compare exact minimax and FPL constraints, holding exact Witt
storage fixed. Report all tested depths and their least feasible interval
counts, canonical minimum with smaller-depth tie-breaking, and all ties.
Finite movement is possible; cost ratios should tend to one in asymptotic
regimes. This is a deterministic grid comparison, not a statistical test.

Structured grid: $d=2$, $k\in\{2,3,4,6,8\}$,
$a h_k\in\{0.25,1,4,10,25\}$ and
$\varepsilon\in\{10^{-3},10^{-6},10^{-12}\}$. Compare exact HS certificate,
response upper envelope, and attained witness lower envelope, with identical
Euler decoding and dense generic storage. Check every tolerance excludes
depths below $k$. Report costs as a bracket; upper/lower envelope optima
must not be called exact response optima. Additional amplitude sweep at $k=2$
checks the corollary's leading log rate.

Independent anchors: high precision decimal scalar errors, Lyndon-word
enumeration of Witt dimensions, exhaustive small integer grids, exact matrix
exponentials for noncommuting bounded variation segments, and the explicit
symmetric Engel witness. Boundary feasibility uses double precision logs;
minimality is checked at $m$ and $m-1$ for each enumerated order. Close
comparisons use high precision decimal arithmetic, including interval counts
beyond exact double-precision integer representation.
