# Archived detailed record: mathematics.md

Snapshot retained during consolidation on 14 October 2026. Current definitions,
claims and evidence are in the parent folder and notebooks 08--09. Dated
implementation counts and exploratory interpretations below are historical.
Relative file names refer to the parent folder. Pre-run designs remain here.

---

# Response distance induced by linear controlled differential equations

Written 22 September 2026, revised 29 September 2026.

This note defines the response based notion of path closeness suggested by
Ferrucci, Perrée and Lyons (2026), derives computable finite versions, and states
the mathematical comparison under study. It supersedes the norm convention in
the earlier response signature proxy.

Companion files in this folder: `literature.md` for prior work and remaining
contributions, `findings.md` for computations and their evidence status, and
`proofs.md` for exact response constants on planar Lie directions, and
`storage.md` for exact bounded variation Euler minimax error, integer storage
optimization and certified pure Engel storage bounds.

## 1. Motivation

A path discrepancy specifies which differences between two paths count as
large. Pointwise norms compare coordinate values. Signature norms compare
iterated integrals. A response discrepancy instead compares how paths act as
drivers of dynamical systems.

Let $X$ and $\widetilde X$ be two paths. Operational closeness for a class
$\mathcal A$ of systems means

$$
X\approx\widetilde X
\quad\Longleftrightarrow\quad
\Phi^A(X)\approx\Phi^A(\widetilde X)
\quad\text{for every }A\in\mathcal A,
$$

where $\Phi^A(X)$ is terminal response of system $A$ driven by $X$. This
definition depends on a chosen response class. Paths may be far in coordinates
while producing similar responses, or close in coordinates while producing a
large response difference in a sensitive system.

Ferrucci, Perrée and Lyons (2026) use this principle to assess compressed path
representations. Their encoding is acceptable when it preserves solutions of
every norm bounded linear controlled differential equation. Present direction
uses the same criterion as a path discrepancy and, eventually, as a possible
training loss.

## 2. Paths, signatures and norms

Let

$$
X:[0,T]\to\mathbb R^d,
\qquad
\widetilde X:[0,T]\to\mathbb R^d
$$

be bounded variation paths. Definitions extend to geometric rough paths through
Lyons' extension theorem and rough differential equation solution theory
(Lyons, Caruana and Lévy, 2007; Friz and Victoir, 2010).

For a word $w=(w_1,\ldots,w_k)\in\{1,\ldots,d\}^k$, define signature coordinate

$$
S^w(X)
=
\int_{0<u_1<\cdots<u_k<T}
dX_{u_1}^{w_1}\cdots dX_{u_k}^{w_k}.
$$

Signature level $k$ is

$$
S^{(k)}(X)
=
\sum_{|w|=k}S^w(X)e_{w_1}\otimes\cdots\otimes e_{w_k}
\in(\mathbb R^d)^{\otimes k}.
$$

Standard word tensors form an orthonormal basis. Hilbert--Schmidt norm is

$$
\lVert D_k\rVert_{\mathrm{HS}}
=
\left(\sum_{|w|=k}|D_k^w|^2\right)^{1/2},
\qquad
D_k=S^{(k)}(X)-S^{(k)}(\widetilde X).
$$

Translation of $X$ does not alter its signature. Starting points must therefore
be anchored separately when they carry information. Time augmentation
$t\mapsto(t,X_t)$ is required when comparison should retain timing rather than
remain invariant under increasing reparameterisation.

## 3. Linear controlled differential equation response

Fix response dimension $n\ge1$. A coefficient is a linear map

$$
A\in\mathcal L\!\left(\mathbb R^d,
\mathcal L(\mathbb R^n,\mathbb R^n)\right),
$$

represented by matrices $A=(A_1,\ldots,A_d)$ with
$A_i\in\mathbb R^{n\times n}$. Its norm is

$$
\lVert A\rVert_F
=
\left(\sum_{i=1}^d\lVert A_i\rVert_F^2\right)^{1/2},
$$

where matrix norm on the right is Frobenius norm. For initial state
$y_0\in\mathbb R^n$, consider

$$
dY_t=\sum_{i=1}^d Y_tA_i\,dX_t^i,
\qquad
Y_0=y_0.
$$

Linearity in $y_0$ gives a terminal operator

$$
\Phi^A_{0,T}(X)\in\mathcal L(\mathbb R^n,\mathbb R^n),
\qquad
Y_T=y_0\Phi^A_{0,T}(X).
$$

Terminal operator is measured with induced Euclidean operator norm

$$
\lVert M\rVert_{\mathrm{op}}
=
\sup_{\lVert y\rVert_2\le1}\lVert My\rVert_2.
$$

This distinction is essential. Ferrucci, Perrée and Lyons use Frobenius norm
for coefficient tuple $A$, Hilbert--Schmidt norm for signature tensors, and
induced operator norm for terminal response.

Picard iteration gives signature expansion

$$
\Phi^A_{0,T}(X)
=
I_n+
\sum_{k=1}^{\infty}
\sum_{|w|=k}
S^w(X)A_{w_1}\cdots A_{w_k}.
$$

States are row vectors and words are chronological. Column-state convention
$dZ=\sum_i A_iZ\,dX^i$ uses reversed matrix products. Transposing the
coefficient tuple converts between these conventions and preserves all
operator-norm suprema here.

## 4. Exact response discrepancy

For response bound $r>0$ and response dimension $n$, define

$$
d_{r,n}(X,\widetilde X)
=
\sup_{\lVert A\rVert_F\le r}
\left\lVert
\Phi^A_{0,T}(X)-\Phi^A_{0,T}(\widetilde X)
\right\rVert_{\mathrm{op}}.
$$

Ferrucci, Perrée and Lyons call $X$ and $\widetilde X$
$(\varepsilon,r)$ close when

$$
d_{r,n}(X,\widetilde X)<\varepsilon.
$$

Response dimension $n$ is part of the definition because different matrix
representations distinguish different signature directions.

For fixed $r$ and $n$, $d_{r,n}$ is a pseudometric on any path class on which
responses exist and remain finite:

1. $d_{r,n}(X,\widetilde X)\ge0$;
2. $d_{r,n}(X,\widetilde X)=d_{r,n}(\widetilde X,X)$;
3. $d_{r,n}(X,X)=0$;
4. triangle inequality follows from operator norm triangle inequality before
   taking supremum over $A$.

Separation may fail for fixed $n$. Linear matrix representations satisfy
polynomial identities, so some nonzero free Lie elements are invisible to every
$n\times n$ response. Even with unrestricted response dimension, signatures
identify bounded variation paths only up to tree-like equivalence (Hambly and
Lyons, 2010). Terminology should therefore remain *response discrepancy* or
*pseudometric* until quotient space and response class are fixed.

The polynomial-identity/development separation connection is already explicit
in Chevyrev and Lyons (2016), §4.2, Theorem 4.8. The restricted norm budget and
quantitative distortion comparisons are the focus here.

Blindness is quantified as follows. Writing $\Phi^A_{0,T}(X)=\exp\rho_A(\log S(X))$
with $\rho_A$ the free Lie algebra representation $e_i\mapsto A_i$, and using
that $\rho_{cA}$ multiplies a degree $k$ Lie element by $c^k$, vanishing of
$d_{r,n}$ forces each homogeneous component of $\log S(X)-\log S(\widetilde X)$
into $\bigcap_A\ker\rho_A$ separately. Exponential form holds while Magnus
series converges, e.g. for $\int_0^T\lVert\sum_iA_i\,dX^i_t\rVert_{\mathrm{op}}<\pi$
(Moan and Niesen, 2008); vanishing on this small ball suffices, and scaling
$A\mapsto cA$ separates degrees. Two consequences:

- null set of $d_{r,n}$ is independent of $r>0$, since $A\mapsto\Phi^A_{0,T}(X)$
  is entire and agreement on a ball forces agreement everywhere;
- first blind homogeneous Lie degree equals minimal degree $m_n(d)$ of a Lie
  identity of $\mathfrak{gl}(n)$ in $d$ variables. A pure level-$k$ weakly
  geometric $p$-rough path, $p\ge k$, generated by such an identity gives
  full response blindness. Arbitrary finite-step group elements do not admit
  well-defined evaluation into general matrices: discarded BCH terms can
  produce nonzero responses.

Known values: $m_2(d)=5$ for $d\ge3$ (`proofs.md` §6.2; the unrestricted
degree-five threshold is recorded by Kanel-Belov, Malev and Rowen);
$m_2(2)=6$ is classical (Nikolaev 1986, Theorem 1); a full-rank finite-field
exclusion through degree five and the explicit identity in `proofs.md` §6.1
reproduce it. Standard Lie identity
$\sum_{\sigma\in S_{n^2}}\operatorname{sgn}(\sigma)\operatorname{ad}_{x_{\sigma(1)}}\cdots\operatorname{ad}_{x_{\sigma(n^2)}}(y)$
vanishes on $\mathfrak{gl}(n)$ because $\operatorname{ad}$ factors through
$\mathfrak{sl}(n)$, of dimension $n^2-1$; hence $m_n(d)\le n^2+1$ when
$d\ge n^2+1$. General values open. Computed values and their range of validity
are in `findings.md`.

Monotonicity and scaling are

$$
r_1\le r_2
\quad\Longrightarrow\quad
d_{r_1,n}(X,\widetilde X)
\le d_{r_2,n}(X,\widetilde X),
$$

and, for rough path dilation $\delta_c$ with
$S^{(k)}(\delta_cX)=c^kS^{(k)}(X)$,

$$
d_{r,n}(\delta_cX,\delta_c\widetilde X)
=d_{|c|r,n}(X,\widetilde X).
$$

Path scale and response bound are therefore one joint modelling choice.

## 5. Truncated response discrepancy

Exact response contains infinitely many signature levels. For depth $L$, define
level response map

$$
R_{A,k}(D_k)
=
\sum_{|w|=k}D_k^wA_{w_1}\cdots A_{w_k},
$$

and truncated response difference

$$
R_{A,\le L}(X,\widetilde X)
=
\sum_{k=1}^L R_{A,k}(D_k).
$$

Corresponding finite discrepancy is

$$
d^{(\le L)}_{r,n}(X,\widetilde X)
=
\sup_{\lVert A\rVert_F\le r}
\left\lVert
R_{A,\le L}(X,\widetilde X)
\right\rVert_{\mathrm{op}}.
$$

One common coefficient tuple $A$ acts at every level. This object is the direct
finite approximation to $d_{r,n}$. Maximising each level separately produces a
different quantity.

## 6. Level-wise response discrepancy

For signature level $k$, define

$$
d^{(k)}_{r,n}(D_k)
=
\sup_{\lVert A\rVert_F\le r}
\lVert R_{A,k}(D_k)\rVert_{\mathrm{op}}.
$$

Homogeneity in $A$ gives

$$
d^{(k)}_{r,n}(D_k)
=r^k d^{(k)}_{1,n}(D_k).
$$

Ferrucci, Perrée and Lyons (2026, eq. (1.9)) apply Cauchy--Schwarz to obtain,
for every $y\in\mathbb R^n$,

$$
\lVert R_{A,k}(D_k)y\rVert_2
\le
\lVert A\rVert_F^k
\lVert D_k\rVert_{\mathrm{HS}}
\lVert y\rVert_2.
$$

Taking supremum over unit $y$ and then over $\lVert A\rVert_F\le r$ gives

$$
d^{(k)}_{r,n}(D_k)
\le
r^k\lVert D_k\rVert_{\mathrm{HS}}.
$$

For $D_k\ne0$, define sharpness ratio

$$
\rho_{k,n}(D_k)
=
\frac{d^{(k)}_{1,n}(D_k)}{\lVert D_k\rVert_{\mathrm{HS}}}
\in[0,1].
$$

Set $\rho_{k,n}(0)=0$. Ratio is invariant under nonzero scalar multiplication
of $D_k$. It measures tensor direction, response dimension and level rather than
overall discrepancy magnitude.

Interpretation is exact:

- $\rho_{k,n}(D_k)=1$: Hilbert--Schmidt bound is attained;
- small $\rho_{k,n}(D_k)$: Hilbert--Schmidt norm substantially overestimates
  response attainable by one bounded system;
- $\rho_{k,n}(D_k)=0$: chosen response class is blind to $D_k$.

## 7. Hierarchy of response bounds

Triangle inequality and interchange of supremum with finite sum give

$$
\begin{aligned}
d^{(\le L)}_{r,n}(X,\widetilde X)
&\le
\sum_{k=1}^L d^{(k)}_{r,n}(D_k)\\
&\le
\sum_{k=1}^L r^k\lVert D_k\rVert_{\mathrm{HS}}\\
&\le
\sum_{k=1}^L r^k\lVert D_k\rVert_1.
\end{aligned}
$$

These four quantities have different meanings:

1. $d^{(\le L)}_{r,n}$: one system $A$ acts across all retained levels;
2. $\sum_k d^{(k)}_{r,n}$: each level may choose its own maximizing system;
3. weighted Hilbert--Schmidt signature discrepancy: basis invariant upper bound;
4. weighted coordinate $\ell^1$ discrepancy: earlier project proxy and looser,
   basis dependent upper bound.

Two sources of looseness are therefore distinct:

- **within-level gap:** cancellation between words, measured by
  $\rho_{k,n}(D_k)$;
- **between-level gap:** maximizing systems for different levels may disagree,
  and level responses may cancel when combined.

Parameter $r$ disappears from one level ratio because both numerator and
denominator scale as $r^k$. It remains essential across levels because it changes
relative weights $r^k$.

## 8. Lower bounds

### 8.1 Single-word shift bound

Fix word $w=(w_1,\ldots,w_k)$ and response dimension $n\ge k+1$. Let
$E_{a,b}$ denote matrix with one at position $(a,b)$ and zero elsewhere. Define

$$
A_i
=
\frac1{\sqrt k}
\sum_{j:w_{k+1-j}=i}E_{j+1,j}.
$$

Across all $A_i$, exactly $k$ entries have magnitude $k^{-1/2}$, hence

$$
\lVert A\rVert_F^2
=
\sum_{i=1}^d\lVert A_i\rVert_F^2
=1.
$$

Matrix product associated with $w$ has

$$
\left(A_{w_1}\cdots A_{w_k}\right)_{k+1,1}
=k^{-k/2},
$$

while every other word has zero in this matrix entry. Therefore

$$
d^{(k)}_{1,n}(D_k)
\ge
k^{-k/2}\max_{|w|=k}|D_k^w|,
\qquad n\ge k+1.
$$

### 8.2 Injective-norm bound

Injective tensor norm is

$$
\lVert D_k\rVert_\varepsilon
=
\sup_{\lVert u_1\rVert_2=\cdots=\lVert u_k\rVert_2=1}
\left|
\langle D_k,u_1\otimes\cdots\otimes u_k\rangle
\right|.
$$

Placing vectors $u_j$ on successive shift blocks gives

$$
d^{(k)}_{1,n}(D_k)
\ge
k^{-k/2}\lVert D_k\rVert_\varepsilon,
\qquad n\ge k+1.
$$

These bounds guarantee nonzero response when one coordinate or one rank-one
contraction is nonzero. Existing computation shows they can remain far below
true response, especially at higher levels.

## 9. Exact benchmark cases

### 9.1 Level one

For $D_1\in\mathbb R^d$,

$$
R_{A,1}(D_1)=\sum_{i=1}^dD_1^iA_i.
$$

Cauchy--Schwarz gives

$$
d^{(1)}_{r,n}(D_1)\le r\lVert D_1\rVert_2.
$$

Choose a fixed rank-one matrix $P$ with
$\lVert P\rVert_F=\lVert P\rVert_{\mathrm{op}}=1$ and

$$
A_i=r\frac{D_1^i}{\lVert D_1\rVert_2}P.
$$

Then $\lVert A\rVert_F=r$ and equality holds:

$$
d^{(1)}_{r,n}(D_1)=r\lVert D_1\rVert_2,
\qquad
\rho_{1,n}(D_1)=1.
$$

### 9.2 Rank-one symmetric tensors

Let $u\in\mathbb R^d$ satisfy $\lVert u\rVert_2=1$ and

$$
D_k=c\,u^{\otimes k}.
$$

Scalar response $n=1$ with $A_i=ru_i$ gives

$$
R_{A,k}(D_k)
=cr^k
\left(\sum_{i=1}^d u_i^2\right)^k
=cr^k.
$$

Since $\lVert D_k\rVert_{\mathrm{HS}}=|c|$, upper bound is attained:

$$
\rho_{k,n}(D_k)=1
\qquad\text{for every }n\ge1.
$$

For $n>1$, same construction embeds through a rank-one projection of Frobenius
and operator norm one.

### 9.3 Symmetric tensors need not attain the bound

At level two, take

$$
D_2=\frac1{\sqrt d}\sum_{i=1}^d e_i\otimes e_i,
\qquad
\lVert D_2\rVert_{\mathrm{HS}}=1.
$$

Then

$$
R_{A,2}(D_2)
=
\frac1{\sqrt d}\sum_{i=1}^dA_i^2.
$$

Using $\lVert A_i^2\rVert_{\mathrm{op}}\le\lVert A_i\rVert_F^2$,

$$
\left\lVert R_{A,2}(D_2)\right\rVert_{\mathrm{op}}
\le
\frac1{\sqrt d}\sum_i\lVert A_i\rVert_F^2
\le\frac1{\sqrt d}.
$$

Equality is attained by one rank-one projection $A_1$ of Frobenius norm one and
$A_i=0$ for $i>1$. Hence

$$
\rho_{2,n}(D_2)=\frac1{\sqrt d}.
$$

Rank-one symmetric tensor has ratio one while isotropic symmetric tensor has
ratio $d^{-1/2}$. Broad symmetry class therefore does not determine sharpness;
finer tensor orbit data matters.

### 9.4 Pure area at level two

For $d\ge2$, let

$$
D_2
=
c(e_1\otimes e_2-e_2\otimes e_1).
$$

Then

$$
R_{A,2}(D_2)=c[A_1,A_2],
\qquad
[A_1,A_2]=A_1A_2-A_2A_1.
$$

Böttcher--Wenzel inequality gives

$$
\lVert[A_1,A_2]\rVert_{\mathrm{op}}
\le
\lVert[A_1,A_2]\rVert_F
\le
\sqrt2\lVert A_1\rVert_F\lVert A_2\rVert_F
\le
\frac1{\sqrt2}
$$

under $\lVert A_1\rVert_F^2+\lVert A_2\rVert_F^2\le1$
(Böttcher and Wenzel, 2008). For $n=2$, equality is attained by

$$
A_1=\frac12
\begin{pmatrix}
1&0\\
0&-1
\end{pmatrix},
\qquad
A_2=\frac1{\sqrt2}
\begin{pmatrix}
0&1\\
0&0
\end{pmatrix}.
$$

Here $[A_1,A_2]=2^{-1/2}E_{1,2}$. Since
$\lVert D_2\rVert_{\mathrm{HS}}=|c|\sqrt2$,

$$
d^{(2)}_{1,n}(D_2)=\frac{|c|}{\sqrt2},
\qquad
\rho_{2,n}(D_2)=\frac12,
\qquad n\ge2.
$$

Thus Hilbert--Schmidt bound overestimates pure-area response by exact factor two.
Scalar responses give zero because scalar matrices commute.

### 9.5 Planar free Lie component at level three

For $d=2$, every nonzero element of the degree-three free Lie component is an
orthogonal coordinate transform and scalar multiple of

$$
E_3=[e_1,[e_1,e_2]].
$$

Repeated use of the Böttcher--Wenzel inequality gives

$$
\lVert[A_1,[A_1,A_2]]\rVert_{\mathrm{op}}
\le2\lVert A_1\rVert_F^2\lVert A_2\rVert_F.
$$

The right side is maximized under
$\lVert A_1\rVert_F^2+\lVert A_2\rVert_F^2\le1$ when the two squared norms are
$2/3$ and $1/3$.  A diagonal $2\times2$ matrix and one nilpotent matrix attain
equality.  Since $\lVert E_3\rVert_{\mathrm{HS}}=\sqrt6$,

$$
\rho_{3,n}(L)=\frac{2\sqrt2}{9}
\qquad
\text{for every }0\ne L\in\mathcal L_3(\mathbb R^2),\ n\ge2.
$$

The rotation reduction, equality case and general iterated-commutator formula
are proved in `proofs.md`.

### 9.6 Exact Engel direction at every level

Let

$$
E_k=\operatorname{ad}_{e_1}^{k-1}(e_2).
$$

For every $k\ge2$ and $n\ge2$, `proofs.md` establishes

$$
d^{(k)}_{1,n}(E_k)
=
\frac{[2(k-1)]^{(k-1)/2}}{k^{k/2}},
$$

and

$$
\rho_{k,n}(E_k)
=
\frac{[2(k-1)]^{(k-1)/2}}
{k^{k/2}\sqrt{\binom{2k-2}{k-1}}}.
$$

In particular,

$$
\rho_{4,n}(E_4)=\frac{3\sqrt{30}}{80}\approx0.205396.
$$

The ratio decays as

$$
\rho_{k,n}(E_k)
\sim
\pi^{1/4}e^{-1/2}2^{-(k-1)/2}(k-1)^{-1/4}.
$$

Thus the Hilbert--Schmidt upper bound is exponentially conservative along one
explicit family of increasingly deep Lie brackets, despite $2\times2$
responses attaining the exact supremum for that family at every level.

### 9.7 Mixed level-four direction

For $G_4=[e_1,[e_2,[e_1,e_2]]]$, `proofs.md` §4.2 proves

$$
\rho_{4,2}(G_4)=\sqrt{\frac{411+41\sqrt{41}}{20480}}\approx0.181348
<\rho_{4,2}(E_4).
$$

So for $n=2$ the ratio is not constant on planar free Lie directions at level
four. For $n\ge3$ this value is a lower bound only.

### 9.8 Single words

For a word $w$ with $m_i$ occurrences of letter $i$, `proofs.md` §6 proves
$\rho_{k,n}(e_w)=\prod_i(m_i/k)^{m_i/2}$ for every $n\ge1$.

### 9.9 Tangent geometry on pure rough paths

Let $L\in\mathcal L_k(\mathbb R^d)$ be homogeneous and consider the pure
level-$k$ rough path

$$
\mathbf X_t^\varepsilon=\exp_\otimes(t\varepsilon L).
$$

Section 7 of `proofs.md` establishes

$$
\lim_{\varepsilon\to0}
\frac{d_{r,n}(\mathbf X^\varepsilon,\mathbf1)}{|\varepsilon|}
=r^k\gamma_{k,n}(L),
$$

with an explicit uniform $O(|\varepsilon|)$ error after division by
$|\varepsilon|$.  Thus $\gamma_{k,n}$ is the tangent gauge induced by the exact
response pseudometric in a pure degree-$k$ direction.

For truncation depth $k\le N<2k$, the statement is exact rather than
asymptotic:

$$
d^{(\le N)}_{r,n}(\mathbf X^\varepsilon,\mathbf1)
=|\varepsilon|r^k\gamma_{k,n}(L).
$$

The corresponding Hilbert--Schmidt certificate is
$|\varepsilon|r^k\lVert L\rVert_{\mathrm{HS}}$, so its overestimation factor is
exactly $1/\rho_{k,n}(L)$.  The constants of §§9.4--9.7 therefore describe
local path geometry, not only a level-wise tensor optimization.

## 10. Composed finite response on a partition

One global truncated signature may suppress local information. Motivated by
the partitioned representations of Ferrucci, Perrée and Lyons, fix a partition

$$
\pi=\{0=t_0<t_1<\cdots<t_m=T\}.
$$

For interval $[t_{j-1},t_j]$, define Euler factor

$$
P_j^A(X)
=
I_n+
\sum_{k=1}^L
\sum_{|w|=k}
S^w_{t_{j-1},t_j}(X)
A_{w_1}\cdots A_{w_k}.
$$

Set $E_0^A(X)=I_n$ and compose chronologically,

$$
E_j^A(X)=E_{j-1}^A(X)P_j^A(X),
\qquad
\mathcal E^A_{L,\pi}(X)=E_m^A(X).
$$

Composed finite response discrepancy is

$$
\widetilde d_{r,n,L,\pi}(X,\widetilde X)
=
\sup_{\lVert A\rVert_F\le r}
\left\lVert
\mathcal E^A_{L,\pi}(X)
-\mathcal E^A_{L,\pi}(\widetilde X)
\right\rVert_{\mathrm{op}}.
$$

One system $A$ is propagated through all intervals. This differs from averaging
independent blockwise signature distances, which restarts comparison on each
block. It is specifically a truncated tensor-signature polynomial. Ferrucci,
Perrée and Lyons store truncated log-signatures and consider Euler and log-ODE
approximations; statements about the polynomial factors here do not
automatically transfer to their log-ODE factors.

Suppose finite responses approximate exact responses uniformly:

$$
\sup_{\lVert A\rVert_F\le r}
\lVert\Phi^A(X)-\mathcal E^A_{L,\pi}(X)\rVert_{\mathrm{op}}
\le\varepsilon_X,
$$

and similarly for $\widetilde X$ with error $\varepsilon_{\widetilde X}$. Two
applications of triangle inequality give

$$
\left|
d_{r,n}(X,\widetilde X)
-\widetilde d_{r,n,L,\pi}(X,\widetilde X)
\right|
\le
\varepsilon_X+\varepsilon_{\widetilde X}.
$$

Equal error bounds $\varepsilon_X=\varepsilon_{\widetilde X}=\varepsilon$ give
error at most $2\varepsilon$. Results of Ferrucci, Perrée and Lyons guide
selection of $L$ and partition size when corresponding regularity assumptions
hold.

## 11. Consequence for loss design

Given model prediction $\widehat Y_\theta^{(i)}$ and target path $Y^{(i)}$, an
exact response loss would be

$$
\mathcal L_{r,n}(\theta)
=
\frac1N\sum_{i=1}^N
d_{r,n}\!\left(
\widehat Y_\theta^{(i)},Y^{(i)}
\right)^2.
$$

Finite training version replaces $d_{r,n}$ with
$d^{(\le L)}_{r,n}$ or $\widetilde d_{r,n,L,\pi}$. Training becomes minimax:

$$
\min_\theta
\frac1N\sum_{i=1}^N
\sup_{\lVert A\rVert_F\le r}
\left\lVert
R_{A,\le L}
\left(
\widehat Y_\theta^{(i)},Y^{(i)}
\right)
\right\rVert_{\mathrm{op}}^2.
$$

Inner optimization is nonconvex. Danskin-type differentiation supplies a
directional derivative or subgradient after a maximizer has been found, but it
does not ensure that numerical ascent finds global maximum. Computation must
therefore report lower estimates, upper bounds and optimization stability
separately.

Loss interpretation differs from signature norm loss:

- Hilbert--Schmidt signature loss treats feature-space magnitude as discrepancy;
- response loss treats worst bounded-system effect as discrepancy;
- small $\rho_{k,n}$ means response loss assigns less weight than
  Hilbert--Schmidt loss to that tensor direction.

This contraction is intended when project goal is behavioural equivalence under
chosen systems. It is undesirable when goal is direct geometric sensitivity.
Neither criterion dominates without specifying application.

## 12. Mathematical study

Central object is map

$$
D_k
\longmapsto
\rho_{k,n}(D_k)
$$

on Hilbert--Schmidt unit sphere in $(\mathbb R^d)^{\otimes k}$. Study has four
parts.

### 12.1 Within-level sharpness

Characterise directions on which Hilbert--Schmidt bound is sharp or loose.
Relevant structure includes:

- symmetric rank-one tensors;
- isotropic symmetric tensors;
- free Lie tensors representing area and higher-order geometry;
- generic tensors;
- actual differences between path signatures.

Ratio is invariant under scalar multiplication and simultaneous orthogonal
coordinate changes. It need not be constant on an entire symmetric or free Lie
subspace.

### 12.2 Response dimension

For each $D_k$, determine whether

$$
d^{(k)}_{1,n}(D_k)
<d^{(k)}_{1,n+1}(D_k)
$$

or whether value stabilises. Equality across numerical runs supplies evidence,
not proof, because each run is a nonconvex lower estimate. Fixed response
dimension may also be blind to some higher-level Lie directions.

Universal sufficiency of $n=2$ is false: `proofs.md` §6.1 gives a planar
degree-six Lie polynomial with $\gamma_{6,2}=0<\gamma_{6,3}$.
Stabilization on restricted classes, including the mixed degree-four direction,
remains open.

Operator-space theory offers a possible route to stabilization, but Smith's
lemma alone does not answer this question. That lemma fixes a linear map with
target $M_n$ and studies its matrix amplifications. Here polynomial evaluation
is a nonlinear diagonal restriction of a $k$-linear map, and increasing $n$
changes the variables, output and joint Frobenius constraint. A valid use of
operator-space stabilization first requires a linearisation or polarisation
whose amplification norm preserves this feasible set.

### 12.3 Between-level compatibility

Measure gap

$$
\sum_{k=1}^L d^{(k)}_{r,n}(D_k)
-d^{(\le L)}_{r,n}(X,\widetilde X).
$$

Large gap means level-wise maximizing systems cannot be realised by one common
$A$, or their responses cancel. This comparison is required before sum of
level-wise suprema can be interpreted as approximation to full response
distance.

### 12.4 Global and local response

Compare full-interval response with composed response on partitions. Balanced
local perturbations can cancel in global low-level signatures. A partition
boundary inside perturbation can expose it, while chronological composition
retains one dynamical system across blocks.

## 13. Evidence required for each claim

Each numerical supremum is a lower estimate. A reliable study should record:

1. multiple initialization seeds and restart counts;
2. response dimensions $n$ separately;
3. induced operator objective and Frobenius coefficient constraint;
4. analytic upper bounds or exhaustive low-dimensional checks where available;
5. distributions over many random tensors or Brownian pairs rather than one
   representative draw;
6. agreement with exact level-one, rank-one symmetric, isotropic symmetric and
   pure-area benchmarks;
7. full truncated response beside sum of level-wise responses;
8. matched global-versus-global and local-versus-local comparisons.

## 14. Current implementation status

Files:

- `src/pathloss/response.py`, `tests/test_response.py`;
- `scripts/study_response_gap.py`, `scripts/check_response_separation.py`;
- `scripts/study_response_composition.py`,
  `scripts/study_response_compression.py`,
  `scripts/study_response_logode_merge.py`,
  `scripts/study_response_area_gauges.py`;
- `results/runs/response_gap/canonical_20261002_seed0/level_ratios.csv`;
- `results/runs/response_composition/canonical_v2_depth{2,3}_seed211`;
- `results/runs/response_compression/canonical_seed211`;
- `results/runs/response_logode_merge/canonical_v6_seed211`;
- `results/runs/response_area_gauges/canonical_v3_seed211`.

Implemented as of 29 September: Frobenius tuple norm on $A$, Hilbert--Schmidt
norm on $D_k$, induced operator norm on the terminal matrix. Norm correction
required by this note is applied. Forty focused tests include the level-one,
rank-one symmetric, isotropic symmetric and pure-area benchmarks, the exact
planar level-three constant, and both proved planar level-four constants at
their established response dimensions. The study was rerun under the corrected
norms; level two and three ratios were unchanged, while several level-four
ratios fell.

Added 29 September: projected ascent for $d^{(\le L)}_{r,n}$ with one common
$A$, composed interval response of §10, and shared block-diagonal constraints.
Mixed-level optimization projects onto coefficient ball rather than sphere,
because cancellation between degrees may put a maximizer in its interior.
Focused tests against scalar polynomial and product formulae, diagonal
blindness, composed and log-ODE gradients, and exact structured constants pass.
Full project suite passes with 234 tests and one optional dependency skip.

`findings.md` Study C records first numerical comparisons of between-level
compatibility and global against composed response. Nonexact computed values
remain nonconvex lower estimates.

`findings.md` Study D and `proofs.md` §8.4 give an exact factor-eight certificate
gap for merging two truncated tensor-signature Euler intervals. This is not yet
a theorem for the truncated log-signature/log-ODE representation used in the
storage analysis of Ferrucci, Perrée and Lyons. Sections 8.5--8.6 and Study E
bridge that representation: the sharp tangent ratio is again $1/8$, a
finite-scale response sandwich and the complete Hilbert--Schmidt certificate
are explicit, and their separation is proved at every positive scale.

Added 30 September: analytic finite-scale lower and upper response bounds for
the two-loop log-ODE merge, the exact all-level Hilbert--Schmidt certificate,
and a proof that the response upper bound is strictly smaller at every positive
scale. Canonical v6 results record both proved bounds beside numerical lower
estimates.

Also added 30 September: exact Gram-matrix certificate formulae for arbitrary
nonorthogonal homogeneous block pairs and finite ordered block families. A
multiblock Lie--Trotter bound gives an all-scale merge theorem in terms of
aggregate response-growth and pairwise-commutator gauges. Equal-norm orthogonal
pairs admit a simpler dimensionless condition; the coordinate-plane loops
satisfy it with substantial margin. Coordinate-plane chains of every length at
least three satisfy the general condition analytically, certifying many-to-one
merges at every positive scale with a uniform separation margin.

Also added 30 September: for arbitrary degree-two area blocks, the individual
response gauge is the top singular value of the skew area matrix divided by
$\sqrt2$. Aggregate $M$ and $K$ admit certified bounds from the leading
eigenvalue of a nonnegative driver-overlap matrix. This makes the response side
of the multiblock criterion directly computable without nonconvex optimization.
The canonical area-gauge study compares these bounds with optimized lower
estimates on random block families and coordinate chains.

## 15. Intended contribution

Added 2 October: `mixed_blocks.md` and versioned notebook 08 prove the sharp
degree-two log-ODE response/HS ratio for any planar BV path on a fixed partition
with nonzero sum of local cubic logs. Positive tails give explicit finite-scale
and perturbation radii. `response_mixed.py`, its tests and deterministic runner
implement those bounds; `findings.md` Study K records the eight-case run.
The full suite now passes 298 tests, with one optional-dependency skip.

Euler storage optimization is now covered by `storage.md` and Study J of
`findings.md`. The exact bounded variation minimax error is the scalar
straight-line expression from FPL (1.13); a product-expansion argument proves
it is also the universal upper bound and gives exact integer optimization.
Leading FPL asymptotics persist. Pure Engel rough paths admit response storage
lower and upper bounds, and the HS certificate's storage overhead grows at
least stretched exponentially with square root of amplitude under fixed Euler
decoding and dense generic storage. General storage optimization for changing
and mixed Lie directions remains open; Study K is a log-ODE distortion theorem,
not a solution to that storage problem.

Ferrucci, Perrée and Lyons establish Hilbert--Schmidt expression as practical
upper bound for bounded linear-system response. Present direction studies
sharpness of that bound as a function of tensor direction, signature level and
response dimension, and uses resulting gauge for interval composition and
compression. An exact coordinate-plane example halves tensor-signature Euler
storage while its Hilbert--Schmidt certificate exceeds true merge error by
factor eight. The analogous log-signature/log-ODE compression separation now
holds at every positive scale without numerical optimization. The Gram-matrix
theorem covers arbitrary nonorthogonal finite block families. The remaining
proof problems are the exact finite-scale response supremum, extension of the
spectral gauge bounds beyond homogeneous degree two, and quantification of
their conservatism on data-derived blocks.

Concise statement is:

> Hilbert--Schmidt signature distance bounds worst-case linear-CDE response, but
> sharpness varies with tensor direction and composition. In a finite
> tensor-signature Euler model, response geometry can certify a merge rejected
> by feature-space norm bounds; the same factor-eight gap persists to leading
> order for log-ODE merging, and a finite-scale separation follows from explicit
> response bounds and the full certificate. The mechanism extends from pairs to
> finite interval families, including explicit all-scale coordinate-loop chains
> of arbitrary length.

## References

Full bibliographic entries are stored in `papers/references.bib`.

- Böttcher and Wenzel (2008): Frobenius commutator inequality used in pure-area
  benchmark.
- Ferrucci, Perrée and Lyons (2026): $(\varepsilon,r)$ representations,
  coefficient and tensor norm convention, response approximation.
- Friz and Victoir (2010): geometric rough paths and rough differential
  equations.
- Hambly and Lyons (2010): signature uniqueness up to tree-like equivalence.
- Moan and Niesen (2008): Magnus series convergence for
  $\int\lVert A(t)\rVert_2\,dt<\pi$.
- Lyons, Caruana and Lévy (2007): linear CDE signature expansion and rough path
  foundations.
