# Archived response-distance records

Detailed snapshots retained during consolidation on 14 October 2026.
Current claims are in the [project index](../README.md), with verification
in the [dated review](../review_2026-10-14.md).

| snapshot | retained material |
|---|---|
| [mathematics](2026-10-14_mathematics.md) | earlier definitions, benchmark derivations and dated implementation history |
| [findings](2026-10-14_findings.md) | detailed tables, optimization budgets and original pre-run designs |
| [mixed blocks](2026-10-14_mixed_blocks.md) | former local proof copy and original deterministic design |

Dated test counts, priorities and source hashes in snapshots describe historical
states. Current evidence labels and scope take precedence.
Existing result directories and the earlier audit remain in their original
locations. These notes retain the repository's ignored status.
