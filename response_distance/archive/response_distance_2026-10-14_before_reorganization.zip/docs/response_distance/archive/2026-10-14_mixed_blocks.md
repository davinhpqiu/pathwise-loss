# Archived detailed record: mixed_blocks.md

Snapshot retained during consolidation on 14 October 2026. Current definitions,
claims and evidence are in the parent folder and notebooks 08--09. Dated
implementation counts and exploratory interpretations below are historical.
Relative file names refer to the parent folder. Pre-run designs remain here.

---

# Planar degree-two log-ODE distortion and robust mixed merges

2 October 2026. Norms and chronological row-state convention follow
`mathematics.md`. These are internal proofs with computational anchors;
independent external review and wider novelty assessment remain outstanding.

## 1. A first-discrepancy lemma

Let $F=1+\sum_{j\ge1}F_j$ and $G=1+\sum_{j\ge1}G_j$ be group-like tensor
series over $\mathbb R^2$, with homogeneous components and absolutely
convergent norm majorants after dilation $\delta_t$, $t\ge0$.
Assume $F_1=G_1$ and $F_2=G_2$. Then
$D_3=F_3-G_3$ is a degree-three free Lie element: it equals
$\log_3 F-\log_3 G$, because all lower terms in the formal logarithm cancel.

Put $h=\lVert D_3\rVert_{\mathrm{HS}}$,
$\rho=2\sqrt2/9$, and define

$$
\Delta_n(t)=\sup_{\lVert A\rVert_F\le1}
\lVert R_A(\delta_t F)-R_A(\delta_t G)\rVert_{\mathrm{op}},
\qquad
\mathcal B(t)=\sum_{j\ge3}t^j\lVert F_j-G_j\rVert_{\mathrm{HS}}.
$$

Here $R_A$ evaluates full tensor series by chronological matrix products.
Suppose response and HS tails satisfy, uniformly over the coefficient ball,

$$
\left\lVert\sum_{j\ge4}t^jR_A(F_j-G_j)\right\rVert_{\mathrm{op}}
\le Q_R(t),
\qquad
\sum_{j\ge4}t^j\lVert F_j-G_j\rVert_{\mathrm{HS}}\le Q_H(t).
$$

For every $n\ge2$, `proofs.md` §3 gives
$\gamma_{3,n}(D_3)=\rho h$. Reverse triangle inequality and uniformity of
the remainder therefore imply

$$
\boxed{
|\Delta_n(t)-\rho h t^3|\le Q_R(t),
\qquad
h t^3\le\mathcal B(t)\le h t^3+Q_H(t).
}
$$

If $h>0$ and both tails are $O(t^4)$, then
$\Delta_n(t)/\mathcal B(t)\to\rho$, uniformly in $n\ge2$.
Quantitatively,
$|\Delta_n(t)/\mathcal B(t)-\rho|
\le(Q_R(t)+\rho Q_H(t))/(ht^3)$.
This is the full response of the displayed series; no evaluation of a finite
nilpotent quotient is used.

## 2. Positive tail and explicit separation radius

For $a,b\ge0$, define the degree-four-and-above tail

$$
T_4(a,b;t)
=e^{at+bt^2}-1-at-\left(\tfrac12a^2+b\right)t^2
-\left(\tfrac16a^3+ab\right)t^3.
$$

It has nonnegative coefficients. Stable numerical evaluation uses $p=at$,
$q=bt^2$ and $P_k(z)=\sum_{j=0}^kz^j/j!$:

$$
T_4(a,b;t)
=e^p-P_3(p)+q(e^p-P_1(p))+e^p(e^q-P_1(q)).
$$

Let $Q_R$ be a sum of such tails. For any reference $T>0$ put
$C_T=Q_R(T)/T^4$. Nonnegative coefficients give
$Q_R(t)\le C_Tt^4$ for $0\le t\le T$.
When $h>0$ and $C_T>0$, set

$$
t_*=\min\left\{T,\frac{(1-\rho)h}{2C_T}\right\},
\qquad c=\frac{1+\rho}{2}<1.
$$

For every $0<t\le t_*$,

$$
\boxed{\Delta_n(t)\le c h t^3<h t^3\le\mathcal B(t).}
$$

Thus tolerance $c h t^3$ is response-feasible and is rejected by the HS
certificate. This radius is sufficient; no maximal-radius claim is made.
The formulas are analytic inequalities. Floating-point evaluations of their
parameters are numerical, without interval-certified rounding.

## 3. Arbitrary planar BV paths and fixed partitions

Let $X$ be a continuous planar BV path of Euclidean variation $L$, with fixed
partition $\pi$. On interval $i$ write its homogeneous log-signature as
$\ell_{i,1}+\ell_{i,2}+\ell_{i,3}+\cdots$. Compare exact signature with
the full series of the degree-two log-ODE decoder:

$$
F=S(X)=\prod_i S(X_i),
\qquad
G_\pi=\prod_i\exp_\otimes(\ell_{i,1}+\ell_{i,2}).
$$

Each pair of interval factors agrees through degree two and differs at degree
three by $\ell_{i,3}$. In the chronological product, multiplying this first
difference by any nonconstant factor raises degree. Consequently

$$
F_1=(G_\pi)_1,\quad F_2=(G_\pi)_2,\quad
\boxed{D_3=\sum_i\ell_{i,3}.}
$$

Set $a=\sum_i\lVert\ell_{i,1}\rVert_2$ and
$b=\sum_i\lVert\ell_{i,2}\rVert_{\mathrm{HS}}$.
BV factorial estimates majorize $F$ by $e^{Lt}$; tensor-product estimates
majorize $G_\pi$ by $e^{at+bt^2}$. Every planar area block has response gauge
half its HS norm (`proofs.md` §3), so the decoder's matrix coefficients are
majorized by $e^{at+(b/2)t^2}$. Therefore valid tails for §1 are

$$
\boxed{
Q_R(t)=T_4(L,0;t)+T_4(a,b/2;t),\qquad
Q_H(t)=T_4(L,0;t)+T_4(a,b;t).
}
$$

This proves the sharp limit $\rho$ and explicit finite-scale separation whenever
$\sum_i\ell_{i,3}\ne0$. For coefficient radius $r$ and path dilation $s$,
substitute joint scale $t=sr$. No pure-block assumption is imposed on $X$.
The result concerns log-ODE decoding and changes no universal Euler storage
asymptotics in `storage.md`.

### Uniformity under BV perturbations

For anchored continuous BV paths $X,Y$ with lengths at most $L$ and
$\eta=\lVert X-Y\rVert_{1\text{-var}}$, multilinearity of iterated integrals
gives

$$
\lVert S_j(X)-S_j(Y)\rVert_{\mathrm{HS}}
\le\frac{\eta L^{j-1}}{(j-1)!}.
$$

One direct proof differentiates $S_j(X+u(Y-X))$ in $u\in[0,1]$. At each
insertion time, sum over the $j$ positions of $\mathrm d(Y-X)$ gives
$(L_{\mathrm{before}}+L_{\mathrm{after}})^{j-1}/(j-1)!$ against its variation
measure. Interpolated length is at most $L$. Integrating in $u$ gives the bound.

Use the degree-three logarithm identity

$$
\ell_3=S_3-\tfrac12(S_1\otimes S_2+S_2\otimes S_1)
+\tfrac13 S_1^{\otimes3}.
$$

The three displayed groups have difference bounds respectively
$\eta L^2/2$, $3\eta L^2/2$, and $\eta L^2$. Hence

$$
\lVert\ell_3(X)-\ell_3(Y)\rVert_{\mathrm{HS}}\le3\eta L^2.
$$

On a common partition, summing local bounds gives the same estimate for
$D_3=\sum_i\ell_{i,3}$: local difference variations sum to $\eta$, and
local lengths are bounded by $L$.
Also $a\le L$ and
$b\le\sum_i L_i^2\le L^2$, because
$\ell_{i,2}=S_{i,2}-S_{i,1}^{\otimes2}/2$.
Thus on any class with total length at most $L$ and $\lVert D_3\rVert\ge h_0>0$,
§2 gives a common radius using
$Q_R^*(t)=T_4(L,0;t)+T_4(L,L^2/2;t)$ and $h=h_0$.
These constants contain no partition-size term; nondegeneracy is still required.

For one baseline path with length $L_X$ and $h_X>0$, put
$L=L_X+1$ and
$\eta_* =\min\{1,h_X/(6L^2)\}$.
Every anchored perturbation within $\eta_*$ has length at most $L$ and
cubic norm at least $h_X/2$. Applying §2 with that lower norm and $Q_R^*$
gives a uniform positive scale radius. This proves perturbation stability for
ordinary BV paths, on any fixed common partition.

## 4. Two mixed displacement/area log blocks

Let $Z=[e_1,e_2]$, $v_i\in\mathbb R^2$ and
$U_i=\alpha_i Z$. Fine and coarse tensor series are

$$
F(t)=e_\otimes^{tv_1+t^2U_1}e_\otimes^{tv_2+t^2U_2},
\qquad
G(t)=e_\otimes^{t(v_1+v_2)+t^2(U_1+U_2+\frac12[v_1,v_2])}.
$$

BCH through degree three, or direct multiplication of degree-three tensor
polynomials, gives $D_3=[w,Z]$, where $\omega=\det(v_1,v_2)$ and

$$
\boxed{w=\tfrac12(\alpha_2v_1-\alpha_1v_2)
+\tfrac{\omega}{12}(v_1-v_2).}
$$

Its HS norm is $h=\sqrt6\lVert w\rVert_2$, because
$[e_1,Z]$ and $[e_2,Z]$ are orthogonal with squared norm six.
Define

$$
a_f=\lVert v_1\rVert+\lVert v_2\rVert,\quad
b_f=\sqrt2(|\alpha_1|+|\alpha_2|),\quad
a_c=\lVert v_1+v_2\rVert,\quad
b_c=\sqrt2\left|\alpha_1+\alpha_2+\tfrac12\omega\right|.
$$

Valid remainders are

$$
Q_R=T_4(a_f,b_f/2;t)+T_4(a_c,b_c/2;t),\qquad
Q_H=T_4(a_f,b_f;t)+T_4(a_c,b_c;t).
$$

Sections 1--2 prove the sharp limit and finite-scale separation for every
$w\ne0$, every $n\ge2$.

### Perturbation stability and degeneracy

Suppose $\lVert v_i\rVert,\lVert v_i'\rVert\le V$,
$|\alpha_i|,|\alpha_i'|\le H$, and each vector/scalar parameter changes by
at most $\eta$. Bilinearity and the determinant bound give

$$
\lVert w'-w\rVert\le(H+V+V^2/2)\eta.
$$

Indeed the area/vector terms contribute $(H+V)\eta$;
$|\omega'-\omega|\le2V\eta$ and the determinant/vector terms contribute
$V^2\eta/2$. If $\lVert w\rVert\ge2\kappa$ and
$\eta\le\kappa/(H+V+V^2/2)$, then $\lVert w'\rVert\ge\kappa$.
Uniform remainder budgets are
$a_f,a_c\le2V$, $b_f\le2\sqrt2H$ and
$b_c\le\sqrt2(2H+V^2/2)$. These give a common radius by §2.

For linearly independent increments, expressing $w$ in their basis gives

$$
w=\left(\tfrac12\alpha_2+\tfrac1{12}\omega\right)v_1
-\left(\tfrac12\alpha_1+\tfrac1{12}\omega\right)v_2.
$$

Thus the cubic term vanishes exactly when
$\alpha_1=\alpha_2=-\omega/6$. This codimension-two set requires a higher-order
analysis. Pure planar area blocks have $v_1=v_2=0$ and commute exactly, so the
merge error is zero. The earlier noncommuting pure-area example used three
driver channels and falls outside this planar setting.

## 5. Evidence and position

`src/pathloss/response_mixed.py` evaluates the analytic remainders and both
neighborhood radii. Tests anchor BCH coefficients against tensor logarithms,
the positive tail against high-precision scalar arithmetic, the sharp cubic
gauge against an explicit matrix tuple, and response bounds against exact
piecewise-linear developments. These checks accompany the proofs.

Classical log-ODE approximation and local/global error representations are
established: Bayer, Breneis and Lyons,
[An adaptive algorithm for rough differential equations](https://arxiv.org/html/2307.12590v1),
§§3--4. This result specifies a worst-case joint-Frobenius response gauge and
its sharp ratio to the full HS difference certificate in planar degree three.
The paper's fixed-system error analysis supplies no immediate theorem about
this supremum ratio. That distinction does not establish novelty.
Ferrucci, Perrée and Lyons,
[Concise representations of a path](https://arxiv.org/abs/2607.26281),
provide the storage/response framework; its record still lists v1 on 2 October.
External review and a wider exact-ratio literature check remain required.

## 6. Deterministic check design

Written before the retained run. Vary joint scale on one-corner and repeated
corner BV paths, a four-step BV path on two intervals, and mixed log blocks.
Hold the coefficient budget at one and use the explicit cubic-attaining
dimension-two matrix tuple; its finite-scale response is a witness lower value,
not the optimized supremum. Include straight paths, interval cubic cancellation,
balanced mixed blocks and commuting planar pure-area blocks as degenerate cases.

Check witness errors against the proved response bounds and check strict
response-upper/HS-lower separation inside the stated radius. Also report scales
outside that radius; the analytic bounds remain valid there, but separation is
not guaranteed. Save case definitions, tables, environment and source hashes in
a fresh directory. No random ascent or training is used. A witness outside its
upper bound, or loss of the certified gap inside its radius, fails the run.
