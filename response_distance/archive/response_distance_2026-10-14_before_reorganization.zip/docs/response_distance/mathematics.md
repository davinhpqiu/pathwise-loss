# Response-distance definitions

Consolidated 14 October 2026. Norms and objects used by the proof appendices.
Detailed earlier exposition is in [archive](archive/2026-10-14_mathematics.md).
Current results are summarized in [notebook 09](../../notebooks/09_response_distance_review.ipynb).

## 1. Objective

Compare effects of path representations on norm-bounded linear systems.
Study distortion between true worst-case response and its weighted
Hilbert--Schmidt (HS) certificate. The operational criterion and development
separation have established precedents; [literature](literature.md) records them.

## 2. Paths, signatures and norms

Unless another class is stated, $X:[0,T]\to\mathbb R^d$ is continuous and
of bounded variation (BV). For a word $w=(w_1,\ldots,w_k)$,

$$
S^w(X)=\int_{0<u_1<\cdots<u_k<T}
dX^{w_1}_{u_1}\cdots dX^{w_k}_{u_k},\qquad
S^{(k)}(X)=\sum_{|w|=k}S^w(X)e_w.
$$

Word tensors $e_w=e_{w_1}\otimes\cdots\otimes e_{w_k}$ are orthonormal:
$\lVert D_k\rVert_{\mathrm{HS}}^2=\sum_{|w|=k}|D_k^w|^2$.
Set $D_k=S^{(k)}(X)-S^{(k)}(\widetilde X)$ for a path pair.
For other decoded series, $D_k$ denotes their specified degree-$k$ difference.

Starting points require separate anchoring when informative. Signatures are
translation invariant and ignore increasing reparameterization; time
augmentation retains timing. Rough-path statements specify their class and
use full extended signatures.

## 3. Linear response

For response dimension $n$, use real matrices $A=(A_1,\ldots,A_d)$ with joint
Frobenius norm $|A|^2=\sum_i\lVert A_i\rVert_F^2$. Row states follow

$$
dY_t=\sum_iY_tA_i\,dX_t^i,\qquad
Y_T=Y_0\Phi^A(X),\qquad
\Phi^A(X)=I_n+\sum_{k\ge1}R_{A,k}(S^{(k)}(X)),
$$

where $R_{A,k}(D)=\sum_{|w|=k}D^wA_{w_1}\cdots A_{w_k}$.
Outputs use Euclidean operator norm. Matrix products are chronological;
transposing tuples converts to column-state conventions with unchanged suprema.
BV factorial bounds ensure absolute convergence.

## 4. Exact response discrepancy

For coefficient radius $r\ge0$,

$$
d_{r,n}(X,\widetilde X)=\sup_{|A|\le r}
\lVert\Phi^A(X)-\Phi^A(\widetilde X)\rVert_{\mathrm{op}}.
$$

This is a pseudometric on classes with finite uniform responses.
It increases with $r$ and $n$; zero-block embedding proves dimension
monotonicity. For real dilation $c$, $S^{(k)}(\delta_cX)=c^kS^{(k)}(X)$ and

$$
d_{r,n}(\delta_cX,\delta_c\widetilde X)
=d_{|c|r,n}(X,\widetilde X).
$$

For BV paths the null set is independent of $r>0$, by analytic continuation
in $A$. Within the convergent small-coefficient logarithm expansion,
equal responses force each homogeneous log-signature difference into the
common kernel of all matrix evaluations. This is the classical
identity/development connection (Chevyrev--Lyons, §4.2).

A homogeneous Lie identity generates a fully blind pure weakly geometric
$p$-rough path when $p$ is at least its degree. At dimension two,
$m_2(2)=6$ (Nikolaev) and $m_2(d)=5$ for $d\ge3$.
The supplied pure example proves no nontrivial BV blindness example.
General matrices do not evaluate a finite-step nilpotent quotient independently
of discarded BCH terms. See [proofs §6](proofs.md#61-a-strict-response-dimension-separation-at-degree-six).

## 5. Truncated response discrepancy

For depth $L$,

$$
d^{(\le L)}_{r,n}(D)=\sup_{|A|\le r}
\left\lVert\sum_{k=1}^LR_{A,k}(D_k)\right\rVert_{\mathrm{op}}.
$$

One tuple acts across every retained degree. This can differ from the sum
of independently optimized level responses.

## 6. Level-wise response discrepancy

For homogeneous $D_k$, define

$$
\gamma_{k,n}(D_k)=\sup_{|A|\le1}\lVert R_{A,k}(D_k)\rVert_{\mathrm{op}},
\qquad d^{(k)}_{r,n}(D_k)=r^k\gamma_{k,n}(D_k).
$$

For $D_k\ne0$, set $\rho_{k,n}(D_k)=\gamma_{k,n}(D_k)/
\lVert D_k\rVert_{\mathrm{HS}}\in[0,1]$, and set $\rho_{k,n}(0)=0$.
The ratio is invariant under nonzero rescaling and simultaneous orthogonal
driver changes. It depends on tensor direction and response dimension.

## 7. Response bounds and certificates

Coefficientwise Cauchy--Schwarz gives

$$
d^{(\le L)}_{r,n}(D)
\le\sum_{k=1}^Lr^k\gamma_{k,n}(D_k)
\le\sum_{k=1}^Lr^k\lVert D_k\rVert_{\mathrm{HS}}
\le\sum_{k=1}^Lr^k\lVert D_k\rVert_1.
$$

Within-level distortion and incompatible maximizing tuples across levels are
separate sources of slack. Numerical lower estimates alone cannot prove a
strict gap between exact suprema.

For full series $F,G$ with convergent certificate, define

$$
\Delta_{r,n}(F,G)=\sup_{|A|\le r}
\lVert R_A(F)-R_A(G)\rVert_{\mathrm{op}},\qquad
\mathcal B_r(F,G)=\sum_{k\ge1}r^k\lVert F_k-G_k\rVert_{\mathrm{HS}}.
$$

A certificate is sufficient for response accuracy. Further length/control
bounds on $\mathcal B_r$ are another layer of conservatism.

## 8. Constructive lower bounds

For $n\ge k+1$ and unit vectors $u_1,\ldots,u_k\in\mathbb R^d$, place their
coordinates on shifts:

$$
A_i=k^{-1/2}\sum_{j=1}^k(u_{k+1-j})_iE_{j+1,j}.
$$

Then $|A|=1$ and the $(k+1,1)$ entry of $R_{A,k}(D)$ is
$k^{-k/2}\langle D,u_1\otimes\cdots\otimes u_k\rangle$. Thus

$$
\gamma_{k,n}(D)\ge k^{-k/2}\lVert D\rVert_\varepsilon
\ge k^{-k/2}\max_w|D^w|,
$$

where $\lVert D\rVert_\varepsilon$ is the supremum of the displayed rank-one
contraction over unit vectors. These bounds guarantee visibility at sufficient
dimension but need not be sharp.

## 9. Exact benchmarks and tangent lemma

For $\lVert u\rVert_2=1$, let $E_k=\operatorname{ad}_{e_1}^{k-1}(e_2)$ and
$G_4=[e_1,[e_2,[e_1,e_2]]]$.

| direction | exact $\rho$ | response dimension |
|---|---|---|
| level one; $c u^{\otimes k}$ | $1$ | $n\ge1$ |
| $d^{-1/2}\sum_i e_i\otimes e_i$ | $d^{-1/2}$ | $n\ge1$ |
| nonzero planar area | $1/2$ | $n\ge2$ |
| nonzero planar cubic Lie tensor | $2\sqrt2/9$ | $n\ge2$ |
| $E_k$, $k\ge2$ | $[2(k-1)]^{(k-1)/2}/(k^{k/2}\sqrt{\binom{2k-2}{k-1}})$ | $n\ge2$ |
| $G_4$ | $\sqrt{(411+41\sqrt{41})/20480}$ | $n=2$ |

Level-one and symmetric cases follow by scalar/rank-one attainment. Detailed
Lie proofs are in [proofs §§2--4](proofs.md#2-exact-formula-for-an-engel-direction).
For a single word with letter counts $m_i$,
$\rho_{k,n}(e_w)=\prod_{i:m_i>0}(m_i/k)^{m_i/2}$ for every $n\ge1$
([§6](proofs.md#6-single-words)).

For homogeneous Lie $L$ of degree $k$, the pure path
$\mathbf X_t^\varepsilon=\exp_\otimes(t\varepsilon L)$ requires $p\ge k$.
Writing $C=r^k\lVert L\rVert_{\mathrm{HS}}$,

$$
\left|\frac{d_{r,n}(\mathbf X^\varepsilon,\mathbf1)}{|\varepsilon|}
-r^k\gamma_{k,n}(L)\right|
\le\frac{|\varepsilon|C^2}{2}e^{|\varepsilon|C}.
$$

For $k\le N<2k$ the truncated response is exactly
$|\varepsilon|r^k\gamma_{k,n}(L)$.
This is uniform first-order exponential analysis; Carnot amplitude scaling is
$|\varepsilon|^{1/k}$. See [proofs §7](proofs.md#7-the-response-gauge-is-the-tangent-path-discrepancy).

## 10. Partitioned decoders

On partition $\pi$, degree-$N$ Euler and log-ODE decoders are respectively

$$
\mathcal E^A_{N,\pi}(X)=\prod_i
\left[I+\sum_{k=1}^NR_{A,k}(S(X_i)_k)\right],
\qquad
\mathcal M^A_{N,\pi}(X)=\prod_i
\exp\left(\sum_{k=1}^NR_{A,k}(\ell_{i,k})\right),
$$

where $\ell_{i,k}$ is local homogeneous log-signature. The same tuple acts on
all factors. Euler products can generate degrees higher than $N$; discarded
degrees and stored log depth are distinct.

Define composed discrepancy $\widetilde d$ by replacing exact responses in
$d_{r,n}$ with the chosen decoder. If each path's uniform decoder error is
at most $\varepsilon_X,\varepsilon_{\widetilde X}$, then

$$
|d_{r,n}(X,\widetilde X)-\widetilde d(X,\widetilde X)|
\le\varepsilon_X+\varepsilon_{\widetilde X}.
$$

Comparing two approximate representations requires their original-path errors.
Exact decoded-factor merge theorems do not remove that requirement.

## 11. Candidate training loss

For a batch of $M$ targets, a candidate objective is
$M^{-1}\sum_{j=1}^M d_{r,n}(\widehat Y_\theta^{(j)},Y^{(j)})^2$,
with a finite or composed version when needed.
This minimax loss is untested here. Inner ascent gives lower estimates;
Danskin-type differentiation requires its hypotheses and an exact maximizing
solution. A linear tuple budget does not by itself certify nonlinear neural
CDE errors.

## 12. Mathematical study

### 12.1 Within-level sharpness

Exact ratios vary by tensor direction; symmetric or Lie labels alone do not
determine them.

### 12.2 Response dimension

Universal sufficiency of $n=2$ is false. Restricted stabilization, including
$G_4$ above dimension two, remains open. Smith's amplification lemma would
require a linearization preserving the changing tuple/output norms.

### 12.3 Between-level compatibility

Exact compatibility beyond available examples is open. Comparisons of
nonconvex lower estimates supply empirical evidence only.

### 12.4 Global and local response

Chronological composition can detect loop order missed by a global low-depth
truncation. The exact example is [proofs §8.3](proofs.md#83-exact-coordinate-plane-loop-order-response).

## 13. Evidence required for each claim

Record objective/output norms, coefficient budget, dimensions, decoder,
scale, seeds, optimizer budget, analytic anchors and source hashes.
Label ascent outputs as lower estimates and computed analytic bounds as
floating-point evaluations. Full sampled modular rank excludes identities;
deficient rank alone requires a symbolic proof. Numerical agreement is neither
dimension sufficiency nor independent mathematical validation.

## 14. Implementation and retained evidence

Modules, runners and commands are indexed in the [repository README](../../README.md#response-distance-and-storage-studies).
[Findings](findings.md) owns the run catalog and empirical claims.
[Review](review_2026-10-14.md) owns dated checks and corrections.
Historical hashes identify source snapshots.

## 15. Current contribution boundary

Candidate contribution is quantitative response/HS distortion and explicit
finite-scale feasibility separation. Classical foundations are attributed in
[literature](literature.md). External proof reading and exact-ratio novelty
verification remain outstanding; the rough-input extension for $2<p<3$ is open.
