# Response-distance evidence catalog

Consolidated 14 October 2026. Definitions are in [mathematics](mathematics.md);
theorems in [proofs](proofs.md), [storage](storage.md) and
[notebook 08](../../notebooks/08_response_distance.ipynb).
Detailed numerical tables and original pre-run designs are retained in
[archive](archive/2026-10-14_findings.md). Current checks belong to
[dated review](review_2026-10-14.md).

## Evidence labels

- **Exact:** a proved formula or symbolic identity under stated hypotheses.
- **Bound:** a proved inequality; floating-point evaluation is not interval
  certified.
- **Lower estimate:** nonconvex ascent or one explicit matrix witness.
- **Modular rank:** full rank excludes a real homogeneous identity;
  deficiency requires symbolic confirmation.
- **Snapshot:** a retained run with its original source hashes and conventions.

Numerical agreement across dimensions, or a difference between two lower
estimates, proves no equality or strict gap between exact suprema.
Pre-29 September terminal-Frobenius results are superseded by operator-output
runs. External mathematical review and exact-ratio novelty verification remain
outstanding.

## Retained runs

Paths are relative to `results/runs/`. Earlier runs remain unchanged.
Commands and all eight runners are in the repository README.

| study | reference | evidence |
|---|---|---|
| A: identity kernels | `response_separation/canonical_20261002_seed211` | overflow-safe modular ranks |
| B: level ratios | `response_gap/canonical_20261002_seed0` | lower estimates, exact benchmarks |
| C: common tuple/composition | `response_composition/canonical_v2_depth2_seed211`, `canonical_v2_depth3_seed211` | lower estimates and exact loop anchor |
| D: tensor Euler merge | `response_compression/canonical_seed211` | exact formulas and lower estimates |
| E: log-ODE merge | `response_logode_merge/canonical_v6_seed211` | response sandwich, tail-controlled HS evaluation, lower estimates |
| I: area gauges | `response_area_gauges/canonical_v3_seed211` | spectral upper bounds versus lower estimates |
| J: storage | `response_storage/canonical_v2_20260930` | global integer searches; pure response costs bracketed |
| K: planar/mixed bounds | `response_mixed/canonical_v2_20261002` | analytic envelopes and explicit witnesses |
| K: review replay | `response_mixed/review_v2_20261014` | same numerical rows; source snapshot after review |
| K: consolidation replay | `response_mixed/consolidated_20261014` | source snapshot after consolidation; see dated review for verification |

Studies F--H are analytic extensions, with formula regressions rather than
separate ascent runs. Existing metadata records historical sources; matching
current files is required only when explicitly stated for a fresh replay.

## Study A: dimension blindness

The sampled rank grid covers drivers $d=2,3,4$, response dimensions $n=2,3,4$,
and degrees through $9,8,6$, respectively. Dimension-two first deficiencies
occur at degree six for two drivers and degree five for three/four drivers.
The corresponding identities are classical and symbolically verified.
Response dimensions three and four have full rank throughout the sampled ranges.

These exclusions concern homogeneous Lie identities. The full blindness
example is a pure rough path requiring $p\ge6$; a BV example is unestablished.
[Proofs §6](proofs.md#61-a-strict-response-dimension-separation-at-degree-six)
contains the dimension-three nonvanishing witness.

## Study B: directional distortion

Closed planar degree-two/three and Engel gauges, plus the mixed degree-four
constant at $n=2$, anchor the optimizer. Formulae are stated once in
[mathematics §9](mathematics.md#9-exact-benchmarks-and-tangent-lemma).
Remaining numerical ratios are lower estimates. Agreement at dimensions
two, three and five supports restricted stabilization but proves none.

## Study C: one system and interval composition

Vertex-order and coordinate-loop examples compare a common coefficient tuple,
independent level maximizers, global truncation and chronological composition.
Confirmation seeds support numerical stability. The observed between-level
difference is not a proved exact supremum gap. The loop-order locality
separation is exact ([proofs §8.3](proofs.md#83-exact-coordinate-plane-loop-order-response)).

## Study D: tensor Euler merging

The coordinate-loop merge has exact response/certificate ratio $1/8$ and
halves generic tensor-coordinate storage.
This uses truncated signature-polynomial factors; translating the comparison
to a different decoder requires its own proof
([§8.4](proofs.md#84-exact-response-aware-merge-gap)).

## Study E: log-ODE merging

The same example has tangent ratio $1/8$, an analytic finite-scale response
sandwich, and strict separation from the full HS certificate at every positive
scale. The exact finite-scale response supremum is open. Tail-controlled
certificate evaluation and ascent occupy distinct roles
([§§8.5--8.6](proofs.md#85-log-ode-merge-gap-at-small-scale)).

## Study F: orthogonal homogeneous blocks

Exact coefficient norms and a sufficient all-scale response/HS condition extend
the example to orthogonal same-layer blocks
([§8.7](proofs.md#87-orthogonal-block-merge-theorem)).

## Study G: nonorthogonal finite families

Gram data determine every homogeneous certificate coefficient. Product-formula
bounds supply a sufficient all-scale condition for any finite ordered family.
The condition has an infinite infimum; a finite scan alone cannot certify it
([§§8.8--8.9](proofs.md#88-gram-matrix-formula-for-nonorthogonal-blocks)).

## Study H: coordinate chains

Analytic coefficient bounds verify the infinite condition for every adjacent
coordinate-loop chain of length at least three. Generic decoded storage falls
by the chain-length factor
([§8.10](proofs.md#810-certified-coordinate-loop-chains)).
Original-path error must be added if the fine factors already approximate a path.

## Study I: area spectral bounds

Individual area gauges are exact. Aggregate growth and commutator quantities
have computable spectral upper bounds; optimized lower estimates show empirical
slack. One eigenproblem computes those gauges, not the entire infinite-level
merge certificate ([§8.11](proofs.md#811-spectral-response-gauge-bounds-for-degree-two-blocks)).

## Study J: storage optimization

Exact BV minimax replaces the additional length envelope while holding Euler
decoding and dense Witt storage fixed. Finite integer optimum sets can move;
leading asymptotics persist. Pure Engel response costs remain lower/upper
brackets, with growing HS-certified overhead in the amplitude regime.
Pure paths also have exact one-factor log-ODE decoding.
See [storage](storage.md) for quantified scope and original grid design.

## Study K: planar BV and mixed blocks

On a fixed partition with nonzero sum of local cubic logs, the full
response/HS ratio tends to $2\sqrt2/9$, uniformly in $n\ge2$.
Explicit finite-scale and BV perturbation radii accompany the proof in
[notebook 08](../../notebooks/08_response_distance.ipynb).

The deterministic design uses eight BV/mixed examples at six scale factors,
analytic bounds and one cubic-attaining tuple. Cubic-zero examples receive
no positive-radius conclusion. An additional matrix regression shows a
square loop can have zero cubic and nonzero quartic error.

## Unrun or unproved extensions

Rough input with $2<p<3$, mesh-uniform nondegeneracy, exact finite-scale
response values, higher-dimensional $G_4$ attainment, broad between-level
distributions and data-driven adaptive compression remain open or unrun.
The central missing validation is independent reading of existing proofs.
