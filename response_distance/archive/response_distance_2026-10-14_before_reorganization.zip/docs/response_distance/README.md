# Response-distance project

Current state: 14 October 2026. Start with
[self-contained sending note](../../output/pdf/response_distance_note.pdf)
and [source archive](../../output/pdf/response_distance_source.zip).
For the internal research map, use
[notebook 09](../../notebooks/09_response_distance_review.ipynb), the concise
overview of results, prior work and limits.
Candidate contribution is quantitative response/certificate distortion and
finite-scale compression decisions. Correctness and novelty require external
mathematical review.

## Core result

For a continuous planar BV path $X$ and a fixed partition $\pi$, compare exact
signature with degree-two log-ODE decoding. If the sum of local cubic
log-signatures is nonzero, worst-case response/full HS error ratio tends to
$2\sqrt2/9$, uniformly in response dimension $n\ge2$.
The proof gives explicit finite-scale and BV perturbation radii.
Homogeneous coordinate-loop families also give all-scale separations.

## Document ownership

| material | authoritative location |
|---|---|
| concise project overview | [notebook 09](../../notebooks/09_response_distance_review.ipynb) |
| planar BV/mixed proof and executable example | [notebook 08](../../notebooks/08_response_distance.ipynb) |
| definitions and norm conventions | [mathematics](mathematics.md) |
| exact constants, identities and homogeneous merges | [proof appendix](proofs.md) |
| BV Euler minimax and pure Engel storage | [storage appendix](storage.md) |
| empirical claims, labels and retained runs | [findings](findings.md) |
| primary-source locators and scope comparisons | [literature](literature.md) |
| dated audit and verification | [14 October review](review_2026-10-14.md) |
| independent audit before sending | [14 October audit](audit_2026-10-14_independent.md) |
| earlier exposition and designs | [archive](archive/README.md) |

Run commands belong to the [repository README](../../README.md#response-distance-and-storage-studies).
Bibliographic entries belong to `papers/references.bib`.
Working notes and results retain their Git-ignored status. The source archive
includes them for reproducibility; PDF and source are covered by the sending
checkpoint.

## Scope and unresolved work

- Fixed partitions and nonzero cubic discrepancy are required for the BV ratio.
  Cubic cancellation can leave quartic error.
- Classical identities, development separation and commutator tools are
  foundations. Exact-ratio novelty remains unverified.
- Exact BV Euler minimax can change finite integer optima; leading storage
  asymptotics persist. Pure Engel response costs remain bracketed within the
  specified Euler/storage workflow.
- All-scale conditions require analytic infinite-level verification.
  Fine/coarse decoder comparisons need original-path errors when applicable.
- Independent reading of existing proofs is the current priority.
  Rough input with $2<p<3$, mesh-uniform nondegeneracy and exact finite-scale
  response values remain open.
