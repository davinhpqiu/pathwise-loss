# Independent audit before sending to supervisor

14 October 2026, after consolidation at checkpoint `f8cccc8` plus uncommitted
changes. Complements the internal [14 October review](review_2026-10-14.md).
Checks here use code paths separate from the project modules where possible.

## Sending closeout, 14 October

The access and exposition findings below are superseded by the self-contained
PDF and accompanying source archive. The note defines its notation, gives
complete central proofs and distinguishes the three constraint layers.
Its concrete examples now have exact rational certificates. Focused
AI-assisted rederivation checks the all-scale infinite comparison and the
storage limits; expert validation and novelty confirmation remain outstanding.
Final verification and checkpoint are recorded in the current review/logbook.

## Verdict

No mathematical error found in any claim checked. Every retained number tested
reproduces from its artifact. Material is not yet in a form a reader outside
the project can open: proofs and results are Git-ignored, and documents are
organised as an internal evidence system rather than an exposition.

## Verified independently

| claim | location | check | outcome |
|---|---|---|---|
| Planar BV ratio $\Delta/\mathcal B\to2\sqrt2/9$ | notebook 08 §§1--3 | Proof read line by line. Separate computation using matrix exponentials only, corner path, Nelder--Mead over $n=2$ tuples, $\mathcal B$ from tensor series to depth 14 | Ratio 0.220, 0.261, 0.286, 0.300, 0.307 at $t=0.4,\ldots,0.025$; gap shrinks linearly, as §1 predicts |
| First-discrepancy lemma and quantitative bound | notebook 08 §1 | Algebra of $\lvert\Delta/\mathcal B-\rho\rvert\le(Q_R+\rho Q_H)/(ht^3)$ rederived | Correct |
| Positive tail, radius $t_*$, constant $c=(1+\rho)/2$ | notebook 08 §2 | Coefficient expansion and stable formula rederived | Correct |
| BV tail majorants and perturbation constant $3\eta L^2$ | notebook 08 §3 | Each group bound rederived; $a\le L$, $b\le L^2$ checked | Correct |
| Mixed-block cubic $w=\tfrac12(\alpha_2v_1-\alpha_1v_2)+\tfrac{\omega}{12}(v_1-v_2)$ | notebook 08 §4 | Rederived from BCH through degree three | Correct; degeneracy set $\alpha_1=\alpha_2=-\omega/6$ confirmed |
| Planar cubic gauge $2\sqrt2/9$, attaining tuple | notebook 08, proofs §3 | Hand computation of $[A,[A,B]]=4E_{12}/(3\sqrt3)$ | Correct |
| Euler error bound $e^R-\prod_iP_N(x_i)$ | storage §1 | 300 random noncommuting BV paths, $n\in\{2,3\}$, $N\le4$, $m\le4$, $r\le4$ | Zero violations; largest error/bound 0.157 |
| Log-concavity identity for $P_N$ | storage §1 | $N=2,\ldots,8$, 61 points on $[0,6]$ | Agreement to $2\times10^{-14}$ |
| Engel witness symmetric with entries $g_k/\sqrt2$ | storage §3 | Direct computation of $\operatorname{ad}^{k-1}$ on the stated block | Correct; unit tuple norm confirmed |
| Bernoulli and Poisson-tail bounds in storage Proposition | storage §2 | Each inequality rederived | Correct; asymptotic limits read, not re-proved |
| $J_6$ vanishes at $n=2$, witness $-6E_{13}/343$ at $n=3$ | proofs §6.1 | Cayley--Hamilton step rederived; 200 random $2\times2$ pairs; witness evaluated | Max entry $10^{-13}$; witness exact |
| $J_5$ vanishes at $n=2$ | proofs §6.2 | 200 random $2\times2$ triples | Max entry $3\times10^{-14}$ |
| Single-word ratio $\prod_i(m_i/k)^{m_i/2}$ | proofs §6 | AM--GM argument read; values $1/2$, $0.3849$, $1/4$ | Correct |
| Tangent lemma remainder | mathematics §9 | $\sum_{j\ge2}x^j/j!\le\tfrac12x^2e^x$ | Correct |
| Constructive lower bound $\lvert A\rvert=1$ | mathematics §8 | Norm computed | Correct |

Earlier audits (29--30 September) independently checked the Engel formula at
$k\le5$, the log-ODE certificate series, the analytic sandwich and the area
gauge. Those checks still apply.

## Artifacts

| study | check | outcome |
|---|---|---|
| K, `response_mixed/consolidated_20261014` | 48 rows recomputed against logical claims | No witness above proved upper bound; all 16 inside-radius rows separate strictly; nondegenerate tangent ratio 0.31426968; byte-identical to `canonical_v2_20261002` |
| J, `response_storage/canonical_v2_20260930` | Optimum sets and storage ratios | Exact BV optimum set differs from length-envelope optimum in 85 of 135 cases; exact/envelope storage ratio between 0.571 and 1 |
| J, notebook 09 example | Hand enumeration of $(N,m)$ at $d=2$, $r=1$, $\varepsilon=10^{-2}$ | Exact optimum $(4,1)$, storage 8; envelope optimum $(5,1)$, storage 14 |
| A, `response_separation/canonical_20261002_seed211` | First deficient level per $(d,n)$ | 6 for $d=2$, 5 for $d=3,4$, at $n=2$; none at $n=3,4$ within levels 9, 8, 6 |
| All eleven retained run references in findings | Existence | All present |

## Repository checks

- Tests: 266 passed, 5 skipped without torch; response suites 134 passed. The
  internal review's 330 with torch is consistent with earlier torch-only counts.
- Notebooks 08 and 09 execute from the notebook folder with no supplied path.
- KaTeX: 4,925 expressions, zero failures.
- 65 relative links and section anchors across these documents and notebooks
  resolve. All eight README runners exist.
- Every work cited in proofs and literature has an entry in
  `papers/references.bib`. Fox (arXiv:2610.11800) and Iserles--Kropielnicka
  (arXiv:2401.06635) were checked against arXiv records.

## Not independently verified

- Exact $G_4$ constant at $n=2$ (proofs §4.2): earlier ascent matched it to
  five decimals; the elimination itself was not repeated.
- All-scale conditions in proofs §§8.7--8.10: read, not re-proved.
- Leading asymptotic formulas in storage §2: inequalities checked, limit
  arguments not re-proved.
- Novelty: unchanged from [literature](literature.md); searches cannot certify
  absence of prior work.

## Corrections made in this audit

- Four sentences opening with a negation, contrary to repository writing rules:
  findings Study A, storage §4, notebook 08 §§3 and 6. Rephrased.
- Stray blank line in the proofs reference list.

## Readiness for an outside reader

1. **Access.** `docs/` and `results/` are Git-ignored. A repository link gives
   notebooks 08 and 09, whose appendices then point to missing files; notebook 09
   says so itself. Either track `docs/response_distance/` as a versioned
   exception, as was done for `neural_ode_operator_experiments.md`, or send a
   self-contained document.
2. **Commit state.** Notebook 09, two test files and changes to five scripts, two
   modules and the bibliography are uncommitted.
3. **Audience.** Documents are organised around ownership tables, evidence labels,
   replays and dated reviews. That structure suits audit, not first reading. A
   supervisor needs problem, theorems with hypotheses, evidence and open
   questions, in that order.
4. **Repetition.** Some form of "external review remains outstanding" appears in
   eleven files. One statement in the covering material suffices.
5. **Unstated headline numbers.** The storage grid result (optimum moves in 85 of
   135 cases, storage reduced by up to 43% at finite parameters) and the HS
   overestimation factor $9/(2\sqrt2)\approx3.18$ on planar cubic directions
   appear nowhere as headline statements.
6. **Notation in notebook 09.** Dilation $\delta_s$ and local log-signatures
   $\ell_{i,j}$ are used in the core statement without definition there.
7. **Likely first question.** The planar ratio is a small-scale limit, and the
   sufficient radius for the corner example is $t_*\approx0.062$. Relevance at
   practical scales rests on the all-scale coordinate-loop theorems and on the
   storage results, which should be presented alongside it.
