# Response gauges and homogeneous merge proofs

Started 29 September 2026; reviewed and organized 14 October 2026.

Full proof appendix; overview is [notebook 09](../../notebooks/09_response_distance_review.ipynb).
[Definitions](mathematics.md) fix joint Frobenius coefficients, operator outputs
and Hilbert--Schmidt tensors. [Literature](literature.md) owns prior-art
comparisons; external mathematical review remains outstanding.

| topic | proof location |
|---|---|
| Engel, planar and mixed degree-four constants | [§§1--5](#1-response-gauge-and-orthogonal-invariance) |
| words and classical identity witnesses | [§6](#6-single-words) |
| uniform tangent lemma | [§7](#7-the-response-gauge-is-the-tangent-path-discrepancy) |
| composition and exact tensor Euler examples | [§§8.1--8.4](#81-telescoping-bound-for-interval-responses) |
| log-ODE, Gram families and coordinate chains | [§§8.5--8.10](#85-log-ode-merge-gap-at-small-scale) |
| area spectral bounds | [§8.11](#811-spectral-response-gauge-bounds-for-degree-two-blocks) |
| Euler minimax/storage | [storage appendix](storage.md) |
| planar BV/mixed distortion | [notebook 08](../../notebooks/08_response_distance.ipynb) |

## 1. Response gauge and orthogonal invariance

For a homogeneous tensor $D\in(\mathbb R^d)^{\otimes k}$, write

$$
\gamma_{k,n}(D)
=
\sup_{\sum_i\lVert A_i\rVert_F^2\le1}
\left\lVert
\sum_{i_1,\ldots,i_k}
D^{i_1\cdots i_k}A_{i_1}\cdots A_{i_k}
\right\rVert_{\mathrm{op}}.
$$

Thus $\rho_{k,n}(D)=\gamma_{k,n}(D)/\lVert D\rVert_{\mathrm{HS}}$
when $D\ne0$.

The gauge is invariant under simultaneous orthogonal changes of driver
coordinates.  If $Q\in O(d)$ and $QD=Q^{\otimes k}D$, then

$$
\gamma_{k,n}(QD)=\gamma_{k,n}(D).
$$

Indeed, evaluation of $Q^{\otimes k}D$ at $(A_1,\ldots,A_d)$ equals evaluation
of $D$ at the orthogonally mixed tuple

$$
B_j=\sum_i Q_{ij}A_i.
$$

The map $A\mapsto B$ is a bijection of the Frobenius unit ball because
$\sum_j\lVert B_j\rVert_F^2=\sum_i\lVert A_i\rVert_F^2$.  Hilbert--Schmidt norm
is invariant under the same action, so $\rho_{k,n}$ is invariant as well.

## 2. Exact formula for an Engel direction

### Theorem

Let $d\ge2$, $n\ge2$, $k\ge2$, and

$$
E_k=\operatorname{ad}_{e_1}^{k-1}(e_2).
$$

Then

$$
\boxed{
\gamma_{k,n}(E_k)
=
\frac{[2(k-1)]^{(k-1)/2}}{k^{k/2}}
}
$$

and

$$
\boxed{
\rho_{k,n}(E_k)
=
\frac{[2(k-1)]^{(k-1)/2}}
{k^{k/2}\sqrt{\binom{2k-2}{k-1}}}.
}
$$

For $n=1$, $\gamma_{k,1}(E_k)=0$ because scalar matrices commute.

### Proof: upper bound

Write $A=A_1$, $B=A_2$, $a=\lVert A\rVert_F$, and
$b=\lVert B\rVert_F$.  Evaluation of $E_k$ is the iterated commutator

$$
\operatorname{ad}_A^{k-1}(B).
$$

The Böttcher--Wenzel inequality (Böttcher and Wenzel, 2008) gives

$$
\lVert[X,Y]\rVert_F
\le\sqrt2\lVert X\rVert_F\lVert Y\rVert_F.
$$

Iteration and the scalar optimization below give this corollary of
Böttcher--Wenzel.

Applying it $k-1$ times, and using operator norm at most Frobenius norm,

$$
\begin{aligned}
\left\lVert\operatorname{ad}_A^{k-1}(B)\right\rVert_{\mathrm{op}}
&\le
\left\lVert\operatorname{ad}_A^{k-1}(B)\right\rVert_F\\
&\le
(\sqrt2)^{k-1}a^{k-1}b.
\end{aligned}
$$

The constraint is $a^2+b^2\le1$; unused matrices can only consume norm, so
they may be set to zero.  Homogeneity puts the maximizer on $a^2+b^2=1$.
Maximizing $a^{k-1}b$ gives

$$
a^2=\frac{k-1}{k},
\qquad
b^2=\frac1k.
$$

Consequently

$$
\gamma_{k,n}(E_k)
\le
(\sqrt2)^{k-1}
\left(\frac{k-1}{k}\right)^{(k-1)/2}
\frac1{\sqrt k}
=
\frac{[2(k-1)]^{(k-1)/2}}{k^{k/2}}.
$$

### Proof: attainment

It is enough to use a $2\times2$ block.  Set

$$
A=
\frac{a}{\sqrt2}
\begin{pmatrix}1&0\\0&-1\end{pmatrix},
\qquad
B=b
\begin{pmatrix}0&1\\0&0\end{pmatrix},
$$

with $a^2=(k-1)/k$ and $b^2=1/k$.  These matrices have Frobenius norms $a$
and $b$, and

$$
\operatorname{ad}_A^{k-1}(B)
=(\sqrt2a)^{k-1}b
\begin{pmatrix}0&1\\0&0\end{pmatrix}.
$$

The last matrix has equal Frobenius and operator norms.  Hence equality holds
at every step of the upper bound.  Embedding this block in the top-left corner
proves attainment for every $n\ge2$.

Here $B$ is an eigenvector of $\operatorname{ad}_A$ with eigenvalue
$\sqrt2\lVert A\rVert_F$ inside an $\mathfrak{sl}_2$ block. Li and Gao (2026)
use the same device at the level of tail asymptotics, building for every
top-level tensor a contractive development in which its tensor norm appears as
an eigenvalue; their result proves Conjecture 2.12 of Boedihardjo, Geng and
Souris (2020) for arbitrary reasonable tensor norms. Present statement differs
in fixing degree and constraining coefficient norm, rather than taking degree to
infinity.

### Proof: tensor norm

Expanding the iterated commutator gives

$$
E_k
=
\sum_{j=0}^{k-1}
(-1)^j\binom{k-1}{j}
e_1^{\otimes(k-1-j)}\otimes e_2\otimes e_1^{\otimes j}.
$$

The displayed word tensors are distinct and orthonormal.  Vandermonde's
identity therefore gives

$$
\lVert E_k\rVert_{\mathrm{HS}}^2
=
\sum_{j=0}^{k-1}\binom{k-1}{j}^2
=
\binom{2k-2}{k-1}.
$$

Dividing the response value by this norm proves the ratio formula.

## 3. Planar consequences at levels two and three

At level two, the planar free Lie component is one-dimensional and spanned by
$E_2=[e_1,e_2]$.  The theorem yields

$$
\gamma_{2,n}(E_2)=\frac1{\sqrt2},
\qquad
\lVert E_2\rVert_{\mathrm{HS}}=\sqrt2,
\qquad
\rho_{2,n}=\frac12.
$$

At level three, a basis is

$$
E_3=[e_1,[e_1,e_2]],
\qquad
F_3=[e_2,[e_1,e_2]].
$$

The tensors are orthogonal and each has squared Hilbert--Schmidt norm six.
Every nonzero planar degree-three Lie element has the form

$$
uE_3+vF_3=[ue_1+ve_2,[e_1,e_2]].
$$

A rotation in $SO(2)$ sends $(u,v)$ to $(\sqrt{u^2+v^2},0)$ and fixes the
oriented area element $[e_1,e_2]$.  Orthogonal invariance and homogeneity thus
reduce every nonzero element to $E_3$.  The theorem gives the exact constant

$$
\boxed{
\rho_{3,n}(L)=\frac{2\sqrt2}{9}
\quad
\text{for every }0\ne L\in\mathcal L_3(\mathbb R^2),\ n\ge2.
}
$$

Scalar responses give zero on both levels because they annihilate all Lie
brackets.

## 4. Level four: Engel and mixed directions

Planar degree-four Lie component $\mathcal L_4(\mathbb R^2)$ has dimension 3,
spanned by $E_4$, its image under $e_1\leftrightarrow e_2$, and one element of
multidegree $(2,2)$.

### 4.1 Engel direction

For

$$
E_4=[e_1,[e_1,[e_1,e_2]]],
$$

theorem of §2 gives

$$
\gamma_{4,n}(E_4)=\frac{3\sqrt6}{8},
\qquad
\lVert E_4\rVert_{\mathrm{HS}}=\sqrt{20},
\qquad
\boxed{
\rho_{4,n}(E_4)=\frac{3\sqrt{30}}{80}
}
\quad(n\ge2).
$$

Swapping $e_1,e_2$ is orthogonal, so the $(1,3)$ Engel direction has same ratio.

### 4.2 Mixed direction

Let

$$
G_4=[e_1,[e_2,[e_1,e_2]]]
=2e_{1212}-e_{1122}-2e_{2121}+e_{2211},
\qquad
\lVert G_4\rVert_{\mathrm{HS}}=\sqrt{10},
$$

with $e_{ijkl}=e_i\otimes e_j\otimes e_k\otimes e_l$.

#### Theorem

For $d\ge2$,

$$
\boxed{
\gamma_{4,2}(G_4)=\sqrt{\frac{411+41\sqrt{41}}{2048}}\approx0.573473,
\qquad
\rho_{4,2}(G_4)=\sqrt{\frac{411+41\sqrt{41}}{20480}}\approx0.181348.
}
$$

Hence $\rho_{4,2}(G_4)<\rho_{4,2}(E_4)$: for $n=2$, $\rho_{4,2}$ is not constant on
$\mathcal L_4(\mathbb R^2)\setminus\{0\}$. For $n\ge3$, embedding in a
$2\times2$ block gives only $\gamma_{4,n}(G_4)\ge\gamma_{4,2}(G_4)$. Ascent at
$n=3,4$ (150 restarts each) returns same value to $10^{-9}$; matching upper bound
is unproved, so level-four anisotropy for $n\ge3$ remains numerical.

#### Proof

*Step 1: reduction to $\mathfrak{sl}_2$.* Only $A=A_1$, $B=A_2$ enter, so other
$A_i$ are set to zero. Scalar parts leave commutators unchanged and add to
Frobenius norm, so $A,B$ are traceless. On traceless $2\times2$ matrices
$XY+YX=\operatorname{tr}(XY)I$, which gives

$$
[A,[B,[A,B]]]=2\operatorname{tr}(AB)[A,B].
$$

Objective is homogeneous of degree 4, so

$$
\gamma_{4,2}(G_4)
=\sup_{\substack{\operatorname{tr}A=\operatorname{tr}B=0\\ \lVert A\rVert_F^2+\lVert B\rVert_F^2=1}}
2\lvert\operatorname{tr}(AB)\rvert\,\lVert[A,B]\rVert_{\mathrm{op}}.
$$

*Step 2: coordinates.* Frobenius-orthonormal basis of $\mathfrak{sl}_2(\mathbb R)$:

$$
H=\tfrac1{\sqrt2}\begin{pmatrix}1&0\\0&-1\end{pmatrix},\quad
S=\tfrac1{\sqrt2}\begin{pmatrix}0&1\\1&0\end{pmatrix},\quad
K=\tfrac1{\sqrt2}\begin{pmatrix}0&1\\-1&0\end{pmatrix}.
$$

Write $A=a_1H+a_2S+a_3K$, $B=b_1H+b_2S+b_3K$, so
$\lVert A\rVert_F=|a|$, $\lVert B\rVert_F=|b|$. Let $z=a\times b$ (cross product in
$\mathbb R^3$) and $M=\operatorname{diag}(1,1,-1)$. From
$\operatorname{tr}H^2=\operatorname{tr}S^2=1$, $\operatorname{tr}K^2=-1$ and
$[H,S]=\sqrt2K$, $[H,K]=\sqrt2S$, $[S,K]=-\sqrt2H$,

$$
\operatorname{tr}(AB)=a^{\top}Mb,
\qquad
[A,B]=\sqrt2\,(-z_1H-z_2S+z_3K).
$$

For traceless $N=xH+yS+wK$, $\lVert N\rVert_F^2=x^2+y^2+w^2$ and
$\det N=-(x^2+y^2-w^2)/2$, so its singular values satisfy
$\sigma_{\max}^2=(\sqrt{x^2+y^2}+|w|)^2/2$. Therefore

$$
\lVert[A,B]\rVert_{\mathrm{op}}=\sqrt{z_1^2+z_2^2}+|z_3|.
$$

*Step 3: fix plane.* Objective vanishes when $z=0$. Otherwise let
$V=\operatorname{span}\{a,b\}$, $\nu=z/|z|$ its unit normal, $\tau=\nu_3^2\in[0,1]$.
Then $\lVert[A,B]\rVert_{\mathrm{op}}=|z|(\sqrt{1-\tau}+\sqrt\tau)$. Restricted
to $V$, form $x^{\top}My$ has matrix $I-2gg^{\top}$ in an orthonormal basis,
$g$ being projection of $e_3$ onto $V$, $|g|^2=1-\tau$; its eigenvalues are 1 and
$\mu=2\tau-1$. Let $Z\in\mathbb R^{2\times2}$ hold coordinates of $a,b$ as columns
in a corresponding eigenbasis and $Q=\operatorname{diag}(1,\mu)$. Then

$$
|z|=|\det Z|,
\qquad
a^{\top}Mb=(Z^{\top}QZ)_{12},
\qquad
\lVert Z\rVert_F=1.
$$

Every plane, hence every $\tau\in[0,1]$, occurs.

*Step 4: optimise $Z$.* Write $Z=R_\psi\Sigma W$ with $R_\psi$ a rotation,
$\Sigma=\operatorname{diag}(\sigma_1,\sigma_2)$, $W\in O(2)$ (a left reflection
$\operatorname{diag}(1,-1)$ commutes with $\Sigma$ and moves right). For symmetric
$T=\begin{pmatrix}x&y\\y&w\end{pmatrix}$,
$\max_{W\in O(2)}|(W^{\top}TW)_{12}|=\sqrt{y^2+(x-w)^2/4}$. Apply this to
$T=\Sigma R_\psi^{\top}QR_\psi\Sigma$ with $m=1-\mu=2(1-\tau)$, $\xi=\sin^2\psi$,
$s=\sigma_1^2$, $P=s(1-s)$:

$$
x=s(1-m\xi),\quad
w=(1-s)(1-m+m\xi),\quad
y^2=P\,m^2\xi(1-\xi),
$$

$$
\det(Z)^2\bigl(y^2+(x-w)^2/4\bigr)
=P\Bigl[Pm^2\xi(1-\xi)+\tfrac14\bigl(2s-1+(1-s)m-m\xi\bigr)^2\Bigr].
$$

Coefficient of $\xi^2$ is $m^2P(\tfrac14-P)\ge0$, so maximum over $\xi\in[0,1]$
is at an endpoint. Endpoint $\xi=1$ with $s$ equals $\xi=0$ with $1-s$. At
$\xi=0$, with $r=1-s$, $2s-1+(1-s)m=1-2\tau r$. Combining with step 3,

$$
\gamma_{4,2}(G_4)^2=\sup_{\tau,r\in[0,1]}\Psi(\tau,r),
\qquad
\Psi=\bigl(1+2\sqrt{\tau(1-\tau)}\bigr)\,r(1-r)\,(1-2\tau r)^2 .
$$

*Step 5: maximise $\Psi$.* Using $1+2\sqrt{\tau(1-\tau)}\le2$ and
$\max_{r}r(1-r)(1-2r)^2=1/16$:

- if $1-2\tau r<0$ then $\tau,r>\tfrac12$ and $0<2\tau r-1\le2r-1$, so $\Psi\le1/8$;
- on $\tau=0$, $\Psi\le1/4$; on $\tau=1$, $\Psi\le1/16$; on $r\in\{0,1\}$ or
  $1-2\tau r=0$, $\Psi=0$.

Point below gives $\Psi\approx0.3289>1/4$, so maximum lies in open set
$U=\{0<\tau<1,\,0<r<1,\,1-2\tau r>0\}$, where $\Psi$ is smooth and positive. With
$q=\sqrt{\tau(1-\tau)}$, stationarity of $\log\Psi$ reads

$$
8\tau r^2-(6\tau+2)r+1=0,
\qquad
(1-2\tau)(1-2\tau r)=4r\bigl(q+2\tau(1-\tau)\bigr).
$$

Second equation fixes $q$ rationally; imposing $q^2=\tau(1-\tau)$ and taking
resultant in $r$ with first equation gives

$$
16\tau(2\tau-1)^3(50\tau^2-53\tau+4)=0.
$$

At $\tau=\tfrac12$ left side of second equation is 0 and right side positive.
At $\tau=(53+7\sqrt{41})/100$ the two roots $r$ give $1-2\tau r<0$ or $q<0$. At
$\tau=(53-7\sqrt{41})/100$ one root exceeds 1; the other is admissible. Unique
critical point in $U$:

$$
\tau_*=\frac{53-7\sqrt{41}}{100},\quad
r_*=\frac{21-\sqrt{41}}{32},\quad
q_*=\frac{21+\sqrt{41}}{100},\quad
1-2\tau_*r_*=\frac{1+\sqrt{41}}{8}.
$$

Then $1+2q_*=(71+\sqrt{41})/50$, $r_*(1-r_*)=(190+10\sqrt{41})/1024$,
$(1-2\tau_*r_*)^2=(42+2\sqrt{41})/64$, and

$$
\Psi(\tau_*,r_*)
=\frac{1600\,(411+41\sqrt{41})}{50\cdot1024\cdot64}
=\frac{411+41\sqrt{41}}{2048}.
$$

Each supremum is over a compact set, so value is attained by $2\times2$
matrices. Dividing by $\lVert G_4\rVert_{\mathrm{HS}}=\sqrt{10}$ gives $\rho$.
$\square$

Resultant and admissibility checks are exact symbolic computations; value
agrees with direct ascent over $2\times2$, $3\times3$ and $4\times4$ tuples.

## 5. Asymptotic consequence

Put $m=k-1$.  The central binomial coefficient satisfies

$$
\binom{2m}{m}\sim\frac{4^m}{\sqrt{\pi m}}.
$$

The exact Engel ratio therefore obeys

$$
\rho_{k,n}(E_k)
\sim
\pi^{1/4}e^{-1/2}
2^{-(k-1)/2}(k-1)^{-1/4}.
$$

Along this explicit family, the Hilbert--Schmidt upper bound becomes
exponentially more conservative with signature level even though a
$2\times2$ response attains the exact response supremum at every level.

| $k$ | $\rho_{k,n}(E_k)$ | overestimate $1/\rho$ |
|---:|---:|---:|
| 2 | 0.500000 | 2.00 |
| 3 | 0.314270 | 3.18 |
| 4 | 0.205396 | 4.87 |
| 5 | 0.136838 | 7.31 |
| 6 | 0.092224 | 10.84 |
| 8 | 0.042787 | 23.37 |
| 10 | 0.020198 | 49.51 |

## 6. Single words

For a word $w$ of length $k$ with $m_i$ occurrences of letter $i$,

$$
\boxed{
\rho_{k,n}(e_{w_1}\otimes\cdots\otimes e_{w_k})=\prod_{i=1}^d\left(\frac{m_i}{k}\right)^{m_i/2}
\quad(n\ge1),
}
$$

with $0^0=1$.

*Proof.* Let $a_i=\lVert A_i\rVert_F$. Then
$\lVert A_{w_1}\cdots A_{w_k}\rVert_{\mathrm{op}}\le\prod_ja_{w_j}=\prod_ia_i^{m_i}$.
Maximising $\sum_im_i\log a_i$ subject to $\sum_ia_i^2=1$ gives $a_i^2=m_i/k$.
Equality holds for $A_i=a_iP$, $P$ a rank-one orthogonal projection, since
$P^k=P$ and $\lVert P\rVert_{\mathrm{op}}=\lVert P\rVert_F=1$. A word tensor
has Hilbert--Schmidt norm 1. $\square$

Examples: $e_1\otimes e_2$ gives $1/2$, $e_{121}$ gives $2/(3\sqrt3)\approx0.3849$,
$e_{1212}$ gives $1/4$, matching single-word rows of `findings.md`.

### 6.1 A strict response-dimension separation at degree six

Define the two-letter homogeneous Lie polynomial

$$
J_6=[E_4,E_2]
=[\operatorname{ad}_{e_1}^{3}(e_2),[e_1,e_2]].
$$

This is Nikolaev's classical two-variable identity: Theorem 1, equation (1),
*Pliska Studia Math. Bulgarica* 8 (1986), 65--76. His left-normed expression
$[x,y,x,x,[x,y]]$ equals the displayed polynomial. The response-dimension
example below applies that identity; its algebraic form and degree-six
two-variable threshold are established prior work.

Then

$$
\gamma_{6,2}(J_6)=0,
\qquad
\gamma_{6,3}(J_6)\ge\frac6{343}>0.
$$

*Proof.* Scalar parts drop out of commutators. For traceless $2\times2$
matrix $A_0$, Cayley--Hamilton gives
$A_0^2=\tfrac12\operatorname{tr}(A_0^2)I$ and hence

$$
\operatorname{ad}_{A_0}^{3}(B)
=2\operatorname{tr}(A_0^2)[A_0,B].
$$

The two factors in $J_6(A,B)$ are proportional, so their commutator vanishes.
For dimension three take $A=\operatorname{diag}(1,0,-2)$ and
$B=E_{12}+E_{23}$. Direct evaluation gives

$$
[A,B]=E_{12}+2E_{23},\qquad
\operatorname{ad}_A^3(B)=E_{12}+8E_{23},\qquad
J_6(A,B)=-6E_{13}.
$$

Their squared joint Frobenius norm is $7$. Dividing both matrices by
$\sqrt7$ gives a unit tuple and response $-6E_{13}/343$. This also proves
$J_6$ is a nonzero free Lie element. $\square$

Thus response dimension two suffices on the Engel family but fails on general
planar Lie directions. For $p\ge6$, the pure weakly geometric rough path
$\mathbf X_t=\exp_\otimes(tJ_6)$ has identity response in dimension two.
The displayed dimension-three witness has square zero, so its full response
differs from identity by $-6E_{13}/343$. This is full response blindness on
an explicit rough-path class. Evaluation of a truncated group element alone
would not establish full response blindness.

### 6.2 The three-letter degree-five identity

For three letters define $J_5=[[[e_1,e_2],[e_1,e_3]],e_1]$.
It vanishes on all $2\times2$ tuples. To see this, discard scalar parts and
use the nondegenerate invariant pairing $\langle A,B\rangle=\operatorname{tr}(AB)$
on the three-dimensional space of traceless matrices. Both $[A,B]$ and $[A,C]$
lie in $A^\perp$. Generically they span this plane, and their commutator is
orthogonal to both by trace invariance, hence proportional to $A$. Its bracket
with $A$ vanishes. Polynomiality extends this identity to every tuple.

It is nonzero in the free Lie algebra: for
$A=\operatorname{diag}(1,0,-2)$, $B=E_{12}$ and $C=E_{23}$,
$[[[A,B],[A,C]],A]=-6E_{13}$.
Combined with full sampled ranks through degree four, this verifies
$m_2(d)=5$ for $d\ge3$. The identity is standard polynomial-identity theory;
no novelty is claimed.

## 7. The response gauge is the tangent path discrepancy

This is a uniform first-order matrix-exponential lemma. Its pure-layer
amplitude scaling differs from Carnot homogeneous distances (Le Donne 2016,
Definition 2.1); no standalone geometric novelty is claimed.

The preceding constants are not only properties of isolated tensor levels.
They give the infinitesimal geometry of the exact response discrepancy on pure
rough paths.

Let $L\in\mathcal L_k(\mathbb R^d)$ be homogeneous of degree $k$, and let

$$
\mathbf X_t^\varepsilon=\exp_\otimes(t\varepsilon L),
\qquad 0\le t\le1,
$$

be the corresponding pure level-$k$ weakly geometric $p$-rough path, with
$p\ge k$. Write
$\mathbf 1$ for the constant rough path.  A matrix representation
$\rho_A:e_i\mapsto A_i$ sends tensor-group exponentials to matrix
exponentials, hence

$$
\Phi^A(\mathbf X^\varepsilon)=
\exp\!\left(\varepsilon\rho_A(L)\right),
\qquad
\Phi^A(\mathbf1)=I_n.
$$

### Theorem

For $r>0$ and $n\ge1$,

$$
\boxed{
\lim_{\varepsilon\to0}
\frac{d_{r,n}(\mathbf X^\varepsilon,\mathbf1)}{|\varepsilon|}
=r^k\gamma_{k,n}(L).
}
$$

More quantitatively, set

$$
C=r^k\lVert L\rVert_{\mathrm{HS}}.
$$

Then for every $\varepsilon\ne0$,

$$
\boxed{
\left|
\frac{d_{r,n}(\mathbf X^\varepsilon,\mathbf1)}{|\varepsilon|}
-r^k\gamma_{k,n}(L)
\right|
\le
\frac{|\varepsilon|}{2}C^2e^{|\varepsilon|C}.
}
$$

*Proof.* Put $M_A=\rho_A(L)$.  Homogeneity of $L$ and the level-wise
Hilbert--Schmidt bound give

$$
\sup_{\lVert A\rVert_F\le r}\lVert M_A\rVert_{\mathrm{op}}
=r^k\gamma_{k,n}(L),
\qquad
\lVert M_A\rVert_{\mathrm{op}}\le C.
$$

The matrix exponential remainder satisfies

$$
\left\lVert
e^{\varepsilon M}-I-\varepsilon M
\right\rVert_{\mathrm{op}}
\le
\frac{|\varepsilon|^2}{2}
\lVert M\rVert_{\mathrm{op}}^2
e^{|\varepsilon|\lVert M\rVert_{\mathrm{op}}}.
$$

After division by $|\varepsilon|$, the reverse triangle inequality shows that
$\lVert e^{\varepsilon M_A}-I\rVert_{\mathrm{op}}/|\varepsilon|$ differs from
$\lVert M_A\rVert_{\mathrm{op}}$ by at most
$|\varepsilon|C^2e^{|\varepsilon|C}/2$, uniformly over the coefficient ball.
For two bounded functions $f,g$ on the same set,
$|\sup f-\sup g|\le\sup|f-g|$.  Taking the two suprema proves the quantitative
bound and therefore the limit. $\square$

### Exact truncated form

The tensor exponential is

$$
\exp_\otimes(\varepsilon L)
=1+\varepsilon L+\frac{\varepsilon^2}{2}L^{\otimes2}+\cdots,
$$

whose nonconstant terms have degrees $k,2k,3k,\ldots$.  Consequently, for any
truncation depth $N$ with $k\le N<2k$,

$$
\boxed{
d^{(\le N)}_{r,n}(\mathbf X^\varepsilon,\mathbf1)
=|\varepsilon|r^k\gamma_{k,n}(L).
}
$$

Over the same depths, the Hilbert--Schmidt response bound is exactly
$|\varepsilon|r^k\lVert L\rVert_{\mathrm{HS}}$.  Their ratio is therefore
$\rho_{k,n}(L)$ without taking a limit.

### Compression consequence

Suppose a representation discards the pure component $\varepsilon L$ and
replaces $\mathbf X^\varepsilon$ by $\mathbf1$.  For any constant

$$
\rho_{k,n}(L)<c<1,
$$

choose response tolerance

$$
\eta_\varepsilon
=c|\varepsilon|r^k\lVert L\rVert_{\mathrm{HS}}.
$$

The Hilbert--Schmidt certificate rejects this representation for every
$\varepsilon\ne0$, because its bound is larger than $\eta_\varepsilon$.  The
quantitative theorem shows that the true exact response discrepancy accepts it
for all sufficiently small $|\varepsilon|$.  Thus directional sharpness can
change an actual compression decision, rather than merely improve a numerical
constant.

This can be made explicit.  Put $x=|\varepsilon|C$.  Dividing the quantitative
remainder by the Hilbert--Schmidt certificate gives

$$
\frac{d_{r,n}(\mathbf X^\varepsilon,\mathbf1)}
{|\varepsilon|r^k\lVert L\rVert_{\mathrm{HS}}}
\le
\rho_{k,n}(L)+\frac{x}{2}e^x.
$$

Hence it is sufficient that

$$
x<\min\left\{1,\frac{2(c-\rho_{k,n}(L))}{e}\right\}
$$

for the true response criterion to accept deletion at tolerance
$\eta_\varepsilon$ while the Hilbert--Schmidt certificate rejects it.

For the Engel family $E_k$, the HS/local-response factor $1/\rho_{k,n}(E_k)$
grows exponentially with $k$ by §5. The normalized tolerance interval
$(\rho_{k,n}(E_k),1)$ has width tending to one.

## 8. Composition and structured response classes

### 8.1 Telescoping bound for interval responses

Let $P_j=P_j^A(X)$ and $Q_j=P_j^A(\widetilde X)$ be truncated response
factors on interval $j$. Chronological products satisfy

$$
P_1\cdots P_m-Q_1\cdots Q_m
=
\sum_{j=1}^m
P_1\cdots P_{j-1}(P_j-Q_j)Q_{j+1}\cdots Q_m.
$$

This follows by adding and subtracting products in which factors are replaced
from left to right. Submultiplicativity gives

$$
\begin{aligned}
\lVert P_1\cdots P_m-Q_1\cdots Q_m\rVert_{\mathrm{op}}
\le
\sum_{j=1}^m
&\left(\prod_{\ell=1}^{j-1}\lVert P_\ell\rVert_{\mathrm{op}}\right)
\lVert P_j-Q_j\rVert_{\mathrm{op}}\\
&\left(\prod_{\ell=j+1}^{m}\lVert Q_\ell\rVert_{\mathrm{op}}\right).
\end{aligned}
$$

For $\lVert A\rVert_F\le r$, level-wise Hilbert--Schmidt bound yields

$$
\lVert P_j^A(X)\rVert_{\mathrm{op}}
\le
1+\sum_{k=1}^L r^k
\lVert S^{(k)}_{t_{j-1},t_j}(X)\rVert_{\mathrm{HS}}
=:M_j(X).
$$

Write $d_j^{(\le L)}$ for common-$A$ truncated response discrepancy on
interval $j$. Taking supremum over coefficient ball gives

$$
\boxed{
\widetilde d_{r,n,L,\pi}(X,\widetilde X)
\le
\sum_{j=1}^m
\left(\prod_{\ell=1}^{j-1} M_\ell(X)\right)
d_j^{(\le L)}
\left(\prod_{\ell=j+1}^{m}M_\ell(\widetilde X)\right).
}
$$

Thus interval errors propagate with explicit response growth factors. If all
factors are bounded by $M$, right side is at most
$M^{m-1}\sum_jd_j^{(\le L)}$. Exact unitary responses and contractive
discretizations have $M\le1$.

### 8.2 Block-diagonal reduction

For matrix class $\mathcal C$, define constrained homogeneous gauge

$$
\gamma^{\mathcal C}_{k,n}(D)
=
\sup_{\substack{A\in\mathcal C\\\lVert A\rVert_F\le1}}
\lVert R_{A,k}(D)\rVert_{\mathrm{op}}.
$$

Let $\mathrm{BD}(b,n)$ contain tuples whose matrices share consecutive
block-diagonal structure with largest block size $b\le n$, including one block
of size $b$. Then

$$
\boxed{
\gamma^{\mathrm{BD}(b,n)}_{k,n}(D)=\gamma_{k,b}(D).
}
$$

*Proof.* Write $A^{(q)}$ for tuple restricted to block $q$, with
$a_q=\lVert A^{(q)}\rVert_F$. Homogeneity and definition of $\gamma$ give

$$
\lVert R_{A^{(q)},k}(D)\rVert_{\mathrm{op}}
\le a_q^k\gamma_{k,b_q}(D)
\le a_q^k\gamma_{k,b}(D).
$$

Response matrix is block diagonal, so its operator norm is maximum over
blocks. Since $\sum_qa_q^2\le1$, upper bound is $\gamma_{k,b}(D)$. Concentrating
entire norm budget in one size-$b$ block attains corresponding supremum.
$\square$

For $b=1$, all matrices commute, so every free Lie element of degree at least
two has zero response. For $b=2$, §2 shows full dense value is retained on every
Engel direction. Sections 3 and 4 further give full planar values at levels two
and three, and mixed level-four value $\gamma_{4,2}(G_4)$. Whether larger dense
blocks increase mixed level-four value remains open.

### 8.3 Exact coordinate-plane loop-order response

Let $U$ be a unit square loop in coordinate plane $(e_1,e_2)$ and $V$ a unit
square loop in plane $(e_2,e_3)$, with corresponding degree-two signatures

$$
u_2=[e_1,e_2],
\qquad
v_2=[e_2,e_3].
$$

Compare concatenations $U*V$ and $V*U$. Since both loops have zero increment,
their signatures start at degree two. Chen products in opposite orders first
differ at degree four:

$$
S(U)S(V)-S(V)S(U)
=u_2\otimes v_2-v_2\otimes u_2+\text{terms of degree at least five}.
$$

Consequently their global signatures agree through degree three. Their
depth-two interval factors are

$$
P_U=I+[A_1,A_2],
\qquad
P_V=I+[A_2,A_3].
$$

Composition in opposite orders gives

$$
P_UP_V-P_VP_U
=
[[A_1,A_2],[A_2,A_3]].
$$

For every $n\ge2$,

$$
\boxed{
\widetilde d_{r,n,2,\{U,V\}}(U*V,V*U)
=\frac{r^4}{2\sqrt2}.
}
$$

*Proof.* Put $a=\lVert A_1\rVert_F$, $b=\lVert A_2\rVert_F$ and
$c=\lVert A_3\rVert_F$. Three applications of operator/Frobenius comparison
and Böttcher--Wenzel give

$$
\begin{aligned}
\lVert[[A_1,A_2],[A_2,A_3]]\rVert_{\mathrm{op}}
&\le
\sqrt2\lVert[A_2,A_3]\rVert_F\lVert[A_1,A_2]\rVert_F\\
&\le2\sqrt2\,ab^2c.
\end{aligned}
$$

Under $a^2+b^2+c^2\le r^2$, first use
$ac\le(r^2-b^2)/2$, then maximize $b^2(r^2-b^2)$. This gives upper bound
$r^4/(2\sqrt2)$.

For attainment at $r=1$, set

$$
H=\frac1{\sqrt2}\begin{pmatrix}1&0\\0&-1\end{pmatrix},
\quad
N=\begin{pmatrix}0&1\\0&0\end{pmatrix},
\quad
M=\begin{pmatrix}0&0\\1&0\end{pmatrix},
$$

and

$$
A_1=\frac12H,
\qquad
A_2=\frac1{\sqrt2}N,
\qquad
A_3=\frac12M.
$$

Tuple Frobenius norm is one. Relations
$[H,N]=\sqrt2N$ and $[N,M]=\sqrt2H$ give

$$
[[A_1,A_2],[A_2,A_3]]
=-\frac1{2\sqrt2}N,
$$

whose operator norm is $1/(2\sqrt2)$. Scaling tuple by $r$ gives factor $r^4$;
embedding block proves every $n\ge2$. $\square$

Diagonal responses give zero because their interval factors commute. By §8.2,
every block-diagonal class containing a $2\times2$ block attains same value.

### 8.4 Exact response-aware merge gap

Keep loops $U,V$ of §8.3. Fine depth-two representation has factors

$$
P_U=I+C_U,
\qquad
P_V=I+C_V,
\qquad
C_U=[A_1,A_2],\quad C_V=[A_2,A_3].
$$

Merged interval has degree-two signature $u_2+v_2$, hence one factor
$P_{U*V}=I+C_U+C_V$. Therefore merge error is

$$
P_UP_V-P_{U*V}=C_UC_V=[A_1,A_2][A_2,A_3].
$$

For unit loops and every $n\ge2$,

$$
\boxed{
\sup_{\lVert A\rVert_F\le r}
\lVert P_UP_V-P_{U*V}\rVert_{\mathrm{op}}
=\frac{r^4}{4}.
}
$$

*Proof.* With $a,b,c$ as in §8.3,

$$
\lVert[A_1,A_2][A_2,A_3]\rVert_{\mathrm{op}}
\le
2ab^2c.
$$

Use $ac\le(r^2-b^2)/2$ and maximize $b^2(r^2-b^2)$ to obtain $r^4/4$.
At $r=1$, use matrices $H,N,M$ of §8.3 and set

$$
A_1=\frac12N,
\qquad
A_2=\frac1{\sqrt2}H,
\qquad
A_3=\frac12M.
$$

Then

$$
[A_1,A_2][A_2,A_3]
=\frac14NM
=\frac14
\begin{pmatrix}1&0\\0&0\end{pmatrix},
$$

which has operator norm $1/4$. Scaling and block embedding complete proof.
$\square$

Fine response polynomial and merged factor first differ at degree four by
$u_2\otimes v_2$. Since $\lVert u_2\rVert_{\mathrm{HS}}=
\lVert v_2\rVert_{\mathrm{HS}}=\sqrt2$, Hilbert--Schmidt certificate is

$$
r^4\lVert u_2\otimes v_2\rVert_{\mathrm{HS}}=2r^4.
$$

Certificate therefore exceeds exact response error by factor eight. If loop
side length is $s$, both values gain factor $s^4$. Ratio remains $1/8$ at every
scale. Two depth-two tensor-signature intervals in dimension three store 24
positive-level coordinates; merged interval stores 12. Any tolerance

$$
\frac{s^4r^4}{4}<\eta<2s^4r^4
$$

accepts this 50% storage reduction under exact response criterion while
Hilbert--Schmidt certificate rejects it.

This theorem concerns the truncated tensor-signature Euler factors defined in
`mathematics.md` §10. Ferrucci, Perrée and Lyons store truncated
log-signatures and also analyse log-ODE approximations. Their merged log-ODE
factor is not $I+C_U+C_V$, so the exact constants above do not transfer
automatically. The next calculation recovers their leading small-scale form.

### 8.5 Log-ODE merge gap at small scale

There is nevertheless a sharp log-ODE analogue at tangent scale. Let the two
square loops have side length $s$, let the coefficient bound be $r$, and put

$$
t=s^2r^2.
$$

After writing $A_i=rB_i$, with $\sum_i\lVert B_i\rVert_F^2\le1$, set

$$
X=[B_1,B_2],\qquad Y=[B_2,B_3].
$$

The fine depth-two log-ODE response is $e^{tX}e^{tY}$, whereas merging the two
intervals and truncating their log-signature at degree two gives
$e^{t(X+Y)}$. Define

$$
\delta_n^{\log}(t)
=
\sup_{\sum_i\lVert B_i\rVert_F^2\le1}
\left\lVert e^{tX}e^{tY}-e^{t(X+Y)}\right\rVert_{\mathrm{op}}.
$$

For every $n\ge2$ and $t\ge0$,

$$
\boxed{
\left|
\delta_n^{\log}(t)-\frac{t^2}{4\sqrt2}
\right|
\le \frac{t^3e^t}{3}.
}
$$

In particular,

$$
\boxed{
\delta_n^{\log}(t)
=\frac{t^2}{4\sqrt2}+O(t^3),
\qquad t\downarrow0.
}
$$

*Proof.* Taylor expansion gives, uniformly over the coefficient ball,

$$
e^{tX}e^{tY}-e^{t(X+Y)}
=\frac{t^2}{2}[X,Y]+R_t.
$$

Write $a=\lVert B_1\rVert_F$, $b=\lVert B_2\rVert_F$ and
$c=\lVert B_3\rVert_F$. Böttcher--Wenzel and Cauchy--Schwarz give

$$
\lVert X\rVert_{\mathrm{op}}+\lVert Y\rVert_{\mathrm{op}}
\le \sqrt2b(a+c)
\le 2b\sqrt{1-b^2}
\le1.
$$

The total operator-norm remainder after degree two is therefore bounded by

$$
\lVert R_t\rVert_{\mathrm{op}}
\le
2\sum_{m=3}^{\infty}\frac{t^m}{m!}
\le\frac{t^3e^t}{3}.
$$

Section 8.3 proves

$$
\sup_{\sum_i\lVert B_i\rVert_F^2\le1}
\lVert[X,Y]\rVert_{\mathrm{op}}
=\frac1{2\sqrt2}
$$

for every $n\ge2$. Taking suprema in the uniform expansion proves the bound.
$\square$

At tensor level the leading merge discrepancy is
$\tfrac12[u_2,v_2]$. The two words $u_2\otimes v_2$ and
$v_2\otimes u_2$ are orthogonal and each has Hilbert--Schmidt norm $2$, hence

$$
\left\lVert\tfrac12[u_2,v_2]\right\rVert_{\mathrm{HS}}=\sqrt2.
$$

The leading Hilbert--Schmidt certificate is therefore $\sqrt2t^2$, while the
true leading response is $t^2/(4\sqrt2)$. Their ratio is again exactly $1/8$.
Thus the factor-eight gap survives for log-ODE merging infinitesimally, although
the finite-$t$ response need not equal its leading term.

### 8.6 Finite-scale log-ODE bounds and compression separation

The log-ODE response of §8.5 admits a nonasymptotic sandwich. For every
$n\ge2$ and $t\ge0$,

$$
\boxed{
\frac{2(e^{t/2}-1)-t}{\sqrt2}
\le
\delta_n^{\log}(t)
\le
\frac{t^2e^t}{4\sqrt2}.
}
$$

*Upper bound.* The error representation is standard: Iserles and Kropielnicka
(arXiv:2401.06635), Theorem 2.1 and §3.1. The application here compares it with
the exact tensor certificate. For fixed matrices $X,Y$, define

$$
F(s)=e^{(t-s)(X+Y)}e^{sX}e^{sY},
\qquad 0\le s\le t.
$$

Then $F(0)=e^{t(X+Y)}$, $F(t)=e^{tX}e^{tY}$, and differentiation gives

$$
F'(s)
=e^{(t-s)(X+Y)}[e^{sX},Y]e^{sY},
$$

with

$$
[e^{sX},Y]
=\int_0^s e^{(s-u)X}[X,Y]e^{uX}\,du.
$$

Put $x=\lVert X\rVert_{\mathrm{op}}$ and
$y=\lVert Y\rVert_{\mathrm{op}}$. Submultiplicativity yields

$$
\lVert F'(s)\rVert_{\mathrm{op}}
\le
s e^{t(x+y)}\lVert[X,Y]\rVert_{\mathrm{op}}.
$$

Section 8.5 gives $x+y\le1$, and §8.3 gives
$\lVert[X,Y]\rVert_{\mathrm{op}}\le1/(2\sqrt2)$. Integrating from zero to
$t$ proves the upper bound.

*Lower bound.* In the matrices $H,S,K$ of §4.2, take the following equivalent
explicit tuple:

$$
B_1=
\begin{pmatrix}
1/4&0\\
-1/(2\sqrt2)&-1/4
\end{pmatrix},
\quad
B_2=
\begin{pmatrix}
0&1/\sqrt2\\
0&0
\end{pmatrix},
\quad
B_3=
\begin{pmatrix}
-1/4&0\\
-1/(2\sqrt2)&1/4
\end{pmatrix}.
$$

Its joint Frobenius norm is one, and

$$
X=[B_1,B_2]
=
\begin{pmatrix}
1/4&1/(2\sqrt2)\\
0&-1/4
\end{pmatrix},
\qquad
Y=[B_2,B_3]
=
\begin{pmatrix}
-1/4&1/(2\sqrt2)\\
0&1/4
\end{pmatrix}.
$$

Direct exponentiation gives

$$
e^{tX}e^{tY}-e^{t(X+Y)}
=
\frac{2(e^{t/2}-1)-t}{\sqrt2}
\begin{pmatrix}0&1\\0&0\end{pmatrix}.
$$

The scalar coefficient is nonnegative. Its operator norm proves the lower
bound for $n=2$, and block embedding proves it for all $n\ge2$. $\square$

The lower bound refines the tangent expansion constructively:

$$
\delta_n^{\log}(t)
\ge
\frac{t^2}{4\sqrt2}
+\frac{t^3}{24\sqrt2}
+O(t^4).
$$

The complete weighted Hilbert--Schmidt certificate is also explicit. Let
$U=u_2$ and $V=v_2$. They are orthogonal degree-two tensors with
$\lVert U\rVert_{\mathrm{HS}}=\lVert V\rVert_{\mathrm{HS}}=\sqrt2$. At
tensor degree $2m$, the fine and merged signatures differ by

$$
D_{2m}
=
\sum_{p+q=m}\frac{U^{\otimes p}\otimes V^{\otimes q}}{p!q!}
-\frac{(U+V)^{\otimes m}}{m!}.
$$

Tensor words in the orthogonal alphabet $\{U,V\}$ are mutually orthogonal.
There are $m+1$ words of the form $U^pV^{m-p}$ and $2^m-m-1$ remaining words.
Using $\sum_{p=0}^m\binom mp^2=\binom{2m}m$ gives

$$
\boxed{
\lVert D_{2m}\rVert_{\mathrm{HS}}
=
\frac{2^{m/2}}{m!}
\sqrt{\binom{2m}{m}-2^m}.
}
$$

Consequently the full certificate for $t=s^2r^2$ is

$$
\boxed{
\mathcal B(t)
=
\sum_{m=2}^{\infty}
t^m\frac{2^{m/2}}{m!}
\sqrt{\binom{2m}{m}-2^m}.
}
$$

Its first two terms are

$$
\mathcal B(t)
\ge
\sqrt2t^2+\frac{2\sqrt6}{3}t^3.
$$

In fact, the certificate has a simple global lower bound. For $m\ge2$,
$\binom{2m}{m}/2^m$ is increasing and equals $3/2$ at $m=2$, because

$$
\frac{\binom{2m+2}{m+1}/2^{m+1}}
{\binom{2m}{m}/2^m}
=\frac{2m+1}{m+1}>1.
$$

Hence

$$
\binom{2m}{m}-2^m\ge2^{m-1},
$$

and termwise summation gives

$$
\boxed{
\mathcal B(t)
\ge
\frac{e^{2t}-1-2t}{\sqrt2}.
}
$$

For every $t>0$,

$$
\frac{t^2e^t}{4\sqrt2}<\mathcal B(t).
$$

Indeed,

$$
e^{2t}-1-2t
=\sum_{k=2}^{\infty}\frac{2^kt^k}{k!},
\qquad
\frac{t^2e^t}{4}
=\sum_{k=2}^{\infty}\frac{t^k}{4(k-2)!}.
$$

The first coefficient strictly exceeds the second at every $k\ge2$, since
$2^{k+2}>k(k-1)$. This inequality is immediate at $k=2,3$ and propagates for
$k\ge3$ because $(k+1)/(k-1)\le2$.

Therefore every tolerance satisfying

$$
\frac{t^2e^t}{4\sqrt2}<\eta<\mathcal B(t),
\qquad t>0,
$$

provably accepts the 50% log-signature storage reduction under the true
response criterion while the Hilbert--Schmidt certificate rejects it. This is
a finite-scale log-ODE compression separation; it does not depend on numerical
optimization or an exact formula for $\delta_n^{\log}(t)$.

### 8.7 Orthogonal-block merge theorem

The certificate calculation extends from coordinate-plane loops to arbitrary
orthogonal homogeneous blocks. Let $U,V$ belong to the same homogeneous tensor
layer and satisfy

$$
\langle U,V\rangle_{\mathrm{HS}}=0,
\qquad
u=\lVert U\rVert_{\mathrm{HS}},
\qquad
v=\lVert V\rVert_{\mathrm{HS}}.
$$

The tensor identity holds without a Lie assumption. Its interpretation as
log-ODE path compression requires Lie log blocks or the explicitly specified
decoded factors. A merge discrepancy between two approximations must also be
combined with fine approximation error when assessing error to an original path.

Compare the fine tensor exponential
$\exp_\otimes(U)\exp_\otimes(V)$ with the merged one
$\exp_\otimes(U+V)$. At meta-degree $m$ their difference $D_m$ obeys

$$
\boxed{
\lVert D_m\rVert_{\mathrm{HS}}^2
=
\frac1{(m!)^2}
\left[
\sum_{p=0}^m
\binom mp^2 u^{2p}v^{2(m-p)}
-(u^2+v^2)^m
\right].
}
$$

Equivalently, in a manifestly nonnegative form,

$$
\lVert D_m\rVert_{\mathrm{HS}}^2
=
\frac1{(m!)^2}
\sum_{p=1}^{m-1}
\binom mp\left(\binom mp-1\right)
u^{2p}v^{2(m-p)}.
$$

*Proof.* A word containing $p$ copies of $U$ and $m-p$ copies of $V$ has
squared norm $u^{2p}v^{2(m-p)}$. In the fine exponential only the monotone word
$U^pV^{m-p}$ occurs, with coefficient $1/(p!(m-p)!)$; every word has coefficient
$1/m!$ in the merged exponential. Orthogonality of $U,V$ makes distinct words
orthogonal. Summing squared coefficient differences and using the binomial
expansion of $(u^2+v^2)^m$ gives the formula. $\square$

The certificate combines with two response gauges to give a scale-uniform merge
criterion, including unequal block norms. For every admissible unit coefficient
tuple $A$, write

$$
X_A=R_A(U),
\qquad
Y_A=R_A(V),
$$

and define

$$
M=\sup_A
\bigl(\lVert X_A\rVert_{\mathrm{op}}+
\lVert Y_A\rVert_{\mathrm{op}}\bigr),
\qquad
K=\sup_A\lVert[X_A,Y_A]\rVert_{\mathrm{op}}.
$$

At scale $\lambda>0$, let

$$
\delta_{U,V}(\lambda)
=
\sup_A
\left\lVert
e^{\lambda X_A}e^{\lambda Y_A}
-e^{\lambda(X_A+Y_A)}
\right\rVert_{\mathrm{op}}.
$$

The Lie--Trotter argument of §8.6 gives

$$
\boxed{
\delta_{U,V}(\lambda)
\le
\frac{\lambda^2K}{2}e^{\lambda M}.
}
$$

For $m\ge2$, put

$$
H_m(u,v)
=
\sqrt{
\sum_{p=1}^{m-1}
\binom mp\left(\binom mp-1\right)
u^{2p}v^{2(m-p)}
}.
$$

The exact certificate at scale $\lambda$ is

$$
\mathcal B_{U,V}(\lambda)
=
\sum_{m=2}^{\infty}\frac{\lambda^m}{m!}H_m(u,v).
$$

Assume $M>0$ and define

$$
T(u,v;M)
=
\inf_{m\ge2}
\frac{2H_m(u,v)}{m(m-1)M^{m-2}}.
$$

If

$$
\boxed{K<T(u,v;M),}
$$

then

$$
\boxed{
\delta_{U,V}(\lambda)
<\mathcal B_{U,V}(\lambda)
\qquad\text{for every }\lambda>0.
}
$$

Indeed, the coefficient of $\lambda^m$ in the exponential response upper bound
is

$$
\frac K2\frac{M^{m-2}}{(m-2)!},
$$

while the exact certificate coefficient is $H_m(u,v)/m!$. The condition
$K<T(u,v;M)$ makes the former strictly smaller at every $m\ge2$.
If $M=0$, then $X_A=Y_A=0$ for every admissible $A$, so the response vanishes
and separation is immediate whenever $u,v>0$. $\square$

For equal-norm blocks $u=v=a>0$, the exact certificate simplifies to

$$
\mathcal B_{U,V}(\lambda)
=
\sum_{m=2}^{\infty}
\frac{(\lambda a)^m}{m!}
\sqrt{\binom{2m}{m}-2^m},
$$

and §8.6 gives

$$
\mathcal B_{U,V}(\lambda)
\ge
\frac{e^{\sqrt2a\lambda}-1-\sqrt2a\lambda}{\sqrt2}.
$$

Set

$$
\theta=\frac{M}{\sqrt2a},
\qquad
\sigma=\frac{K}{\sqrt2a^2},
$$

and, for $0\le\theta<1$, define the positive threshold

$$
C(\theta)
=
\frac{2}{\displaystyle\sup_{m\ge2}
m(m-1)\theta^{m-2}}.
$$

If

$$
\boxed{
\theta<1
\quad\text{and}\quad
\sigma<C(\theta),
}
$$

then for every $\lambda>0$,

$$
\boxed{
\delta_{U,V}(\lambda)
<
\mathcal B_{U,V}(\lambda).
}
$$

*Proof.* The coefficient of $\lambda^m$ in the exponential response upper bound
remains

$$
\frac K2\frac{M^{m-2}}{(m-2)!},
$$

whereas the coefficient in the displayed certificate lower bound is

$$
\frac{(\sqrt2a)^m}{\sqrt2m!}.
$$

Their ratio is

$$
\frac\sigma2m(m-1)\theta^{m-2}.
$$

The hypothesis makes this ratio strictly below one at every $m\ge2$, so
coefficientwise comparison proves the claim. $\square$

For the coordinate-plane blocks of §§8.5--8.6,

$$
a=\sqrt2,
\qquad M\le1,
\qquad K=\frac1{2\sqrt2}.
$$

Thus $\theta\le1/2$, $\sigma=1/8$, and
$C(1/2)=2/3$, with the supremum in its denominator attained at $m=3,4$.
The general criterion therefore recovers the global separation with substantial
margin.

### 8.8 Gram-matrix formula for nonorthogonal blocks

Orthogonality is not needed for an exact certificate. Let $U,V$ be arbitrary
elements of the same homogeneous tensor layer and write

$$
a=\lVert U\rVert_{\mathrm{HS}}^2,
\qquad
b=\lVert V\rVert_{\mathrm{HS}}^2,
\qquad
c=\langle U,V\rangle_{\mathrm{HS}}.
$$

Their Gram matrix is positive semidefinite, so $c^2\le ab$. At meta-degree
$m$, define

$$
F_m
=
\sum_{p=0}^m\frac{U^{\otimes p}\otimes V^{\otimes(m-p)}}{p!(m-p)!},
\qquad
G_m
=
\frac{(U+V)^{\otimes m}}{m!}.
$$

Then $D_m=F_m-G_m$ and

$$
\boxed{
\lVert D_m\rVert_{\mathrm{HS}}^2
=
\frac1{(m!)^2}
\left[
\sum_{p,q=0}^m
\binom mp\binom mq
a^{\min(p,q)}
b^{m-\max(p,q)}
c^{|p-q|}
-(a+b+2c)^m
\right].
}
$$

*Proof.* For monotone words
$W_p=U^{\otimes p}\otimes V^{\otimes(m-p)}$,

$$
\langle W_p,W_q\rangle
=
a^{\min(p,q)}b^{m-\max(p,q)}c^{|p-q|}.
$$

This gives the double sum for $\lVert F_m\rVert^2$. Also

$$
\langle W_p,(U+V)^{\otimes m}\rangle
=(a+c)^p(b+c)^{m-p}.
$$

The binomial theorem therefore gives

$$
\langle F_m,G_m\rangle
=\frac{(a+b+2c)^m}{(m!)^2}
=\lVert G_m\rVert^2.
$$

Thus $\lVert F_m-G_m\rVert^2=\lVert F_m\rVert^2-\lVert G_m\rVert^2$, proving
the formula. $\square$

Let

$$
H_m(U,V)=m!\lVert D_m\rVert_{\mathrm{HS}}.
$$

The exact certificate is

$$
\mathcal B_{U,V}(\lambda)
=\sum_{m=2}^{\infty}\frac{\lambda^m}{m!}H_m(U,V).
$$

The response gauges $M,K$ and Lie--Trotter upper bound of §8.7 require no
orthogonality. Hence, for $M>0$, the condition

$$
\boxed{
K<\inf_{m\ge2}
\frac{2H_m(U,V)}{m(m-1)M^{m-2}}
}
$$

implies

$$
\delta_{U,V}(\lambda)<\mathcal B_{U,V}(\lambda)
\qquad\text{for every }\lambda>0.
$$

This is the general two-block merge theorem: the feature-side calculation uses
only the Gram matrix $(a,b,c)$, while the response side uses only $M$ and $K$.
If $U,V$ are collinear, every $H_m$ and $K$ vanish, reflecting that the fine and
merged exponentials agree exactly.

### 8.9 Arbitrary finite block families

The preceding result extends to merging any finite ordered family, which is
the form needed by an adaptive partition. Let $U_1,\ldots,U_\ell$ belong to the
same homogeneous tensor layer and let

$$
g_{ij}=\langle U_i,U_j\rangle_{\mathrm{HS}}
$$

be their Gram matrix. For a weak composition
$\alpha=(\alpha_1,\ldots,\alpha_\ell)$ of $m$, write
$\alpha!=\prod_i\alpha_i!$, $\binom m\alpha=m!/\alpha!$, and let $w(\alpha)$
be the nondecreasing word with $\alpha_i$ copies of $i$. Define

$$
W_\alpha
=U_1^{\otimes\alpha_1}\otimes\cdots\otimes
U_\ell^{\otimes\alpha_\ell}.
$$

The meta-degree-$m$ parts of the fine and merged representations are

$$
F_m=\sum_{|\alpha|=m}\frac{W_\alpha}{\alpha!},
\qquad
G_m=\frac{(U_1+\cdots+U_\ell)^{\otimes m}}{m!}.
$$

Set $D_m=F_m-G_m$ and $H_m=m!\lVert D_m\rVert_{\mathrm{HS}}$. Then

$$
\boxed{
H_m^2
=
\sum_{|\alpha|=|\beta|=m}
\binom m\alpha\binom m\beta
\prod_{r=1}^m
g_{w(\alpha)_r,w(\beta)_r}
-\left(\sum_{i,j=1}^\ell g_{ij}\right)^m.
}
$$

Thus every level of the exact Hilbert--Schmidt merge certificate depends only
on the $\ell\times\ell$ Gram matrix, even when blocks are nonorthogonal.

*Proof.* Coordinatewise tensor inner products give

$$
\langle W_\alpha,W_\beta\rangle
=\prod_{r=1}^m g_{w(\alpha)_r,w(\beta)_r},
$$

which produces the double sum for $\lVert F_m\rVert^2$. Put
$s_i=\sum_jg_{ij}$. Then

$$
\langle W_\alpha,(U_1+\cdots+U_\ell)^{\otimes m}\rangle
=\prod_i s_i^{\alpha_i}.
$$

The multinomial theorem yields

$$
\langle F_m,G_m\rangle
=\frac1{m!}\sum_{|\alpha|=m}\frac{\prod_i s_i^{\alpha_i}}{\alpha!}
=\frac{(\sum_i s_i)^m}{(m!)^2}
=\lVert G_m\rVert^2.
$$

Therefore $\lVert D_m\rVert^2=\lVert F_m\rVert^2-\lVert G_m\rVert^2$,
which is the displayed formula after multiplication by $(m!)^2$. $\square$

There is also a response-side bound with no dependence on the number of
blocks other than through two aggregate gauges. For fixed $A$, write
$X_i=R_A(U_i)$, and define

$$
M=\sup_A\sum_{i=1}^\ell\lVert X_i\rVert_{\mathrm{op}},
\qquad
K=\sup_A\sum_{1\le i<j\le\ell}
\lVert[X_i,X_j]\rVert_{\mathrm{op}}.
$$

Then

$$
\boxed{
\delta_{U_1,\ldots,U_\ell}(\lambda)
\le\frac{\lambda^2K}{2}e^{\lambda M}.
}
$$

*Proof.* The two-factor Lie--Trotter bound and induction give, for arbitrary
matrices $X_1,\ldots,X_\ell$,

$$
\left\lVert
e^{\lambda X_1}\cdots e^{\lambda X_\ell}
-e^{\lambda\sum_iX_i}
\right\rVert_{\mathrm{op}}
\le
\frac{\lambda^2}{2}
e^{\lambda\sum_i\lVert X_i\rVert_{\mathrm{op}}}
\sum_{i<j}\lVert[X_i,X_j]\rVert_{\mathrm{op}}.
$$

Indeed, append $e^{\lambda X_j}$ to the first $j-1$ factors. The previous
error is multiplied by at most $e^{\lambda\lVert X_j\rVert}$, while the new
two-factor error contains
$[\sum_{i<j}X_i,X_j]=\sum_{i<j}[X_i,X_j]$. Every term is bounded by the same
final exponential factor. Taking the supremum over $A$ proves the claim.
$\square$

Consequently, for $M>0$, the completely explicit coefficientwise condition

$$
\boxed{
K<\inf_{m\ge2}
\frac{2H_m}{m(m-1)M^{m-2}}
}
$$

implies

$$
\delta_{U_1,\ldots,U_\ell}(\lambda)
<
\sum_{m=2}^{\infty}\frac{\lambda^m}{m!}H_m
$$

for every $\lambda>0$. The right side is the exact full weighted
Hilbert--Schmidt certificate. This reduces a many-interval compression decision
to a Gram-matrix calculation and bounds on two response gauges. The condition
is sufficient rather than necessary: summing pairwise commutator norms discards
cancellation between different pairs.

### 8.10 Certified coordinate-loop chains

The multiblock criterion is nonvacuous in a natural path example. In driver
dimension four, take the three adjacent coordinate-plane area tensors

$$
U_1=[e_1,e_2],
\qquad
U_2=[e_2,e_3],
\qquad
U_3=[e_3,e_4].
$$

They are pairwise orthogonal and each has Hilbert--Schmidt norm $\sqrt2$.
For $X_i=R_A(U_i)=[A_i,A_{i+1}]$, put
$a_i=\lVert A_i\rVert_F$ and

$$
c_*=\cos\frac\pi5.
$$

The largest eigenvalue of the four-vertex path quadratic form gives

$$
\sum_{i=1}^3a_ia_{i+1}
\le c_*\sum_{i=1}^4a_i^2
\le c_*.
$$

Böttcher--Wenzel therefore yields the response-gauge bounds

$$
M
\le\sqrt2\sum_{i=1}^3a_ia_{i+1}
\le\sqrt2c_*,
$$

and

$$
\begin{aligned}
K
&\le\sqrt2\sum_{i<j}\lVert X_i\rVert_F\lVert X_j\rVert_F\\
&\le2\sqrt2\sum_{i<j}
(a_ia_{i+1})(a_ja_{j+1})\\
&\le\sqrt2\left(\sum_{i=1}^3a_ia_{i+1}\right)^2
\le\sqrt2c_*^2.
\end{aligned}
$$

It remains to lower-bound the exact certificate coefficients. After
multiplication by $m!$, every nonmonotone word in the orthogonal alphabet
$\{U_1,U_2,U_3\}$ occurs in the merged representation with coefficient one
and is absent from the fine representation. There are $3^m$ words in total and
$\binom{m+2}{2}$ nondecreasing words. Hence

$$
H_m^2
\ge2^m\left(3^m-\binom{m+2}{2}\right)
\ge2^m3^{m-1},
\qquad m\ge2,
$$

where the last inequality follows from
$\binom{m+2}{2}\le2\cdot3^{m-1}$.
Using the upper bound $M\le\sqrt2c_*$,

$$
\frac{2H_m}{m(m-1)M^{m-2}}
\ge
L_m
:=
\frac{4\,3^{(m-1)/2}c_*^{-(m-2)}}{m(m-1)}.
$$

Now $L_2=2\sqrt3$, $L_3=2/c_*$, and

$$
\frac{L_{m+1}}{L_m}
=\frac{\sqrt3}{c_*}\frac{m-1}{m+1}>1,
\qquad m\ge3.
$$

Thus every coefficient threshold is at least $2/c_*$, whereas

$$
K\le\sqrt2c_*^2<\frac2{c_*}.
$$

The theorem of §8.9 now gives

$$
\boxed{
\delta_{U_1,U_2,U_3}(\lambda)
<\mathcal B_{U_1,U_2,U_3}(\lambda)
\quad\text{for every }\lambda>0.
}
$$

Hence merging these three depth-two log-signature intervals into one is
accepted by a nonempty interval of response tolerances that the exact weighted
Hilbert--Schmidt certificate rejects, at every positive scale. In a generic
dimension-four depth-two log-signature layout, this changes storage from three
copies of ten coordinates to one copy of ten.

The same argument gives an infinite family. For any $\ell\ge3$, work in driver
dimension $\ell+1$ and take

$$
U_i=[e_i,e_{i+1}],
\qquad 1\le i\le\ell.
$$

Put $c_\ell=\cos(\pi/(\ell+2))$. The path-graph quadratic form and the same two
Böttcher--Wenzel estimates give

$$
M\le\sqrt2c_\ell<\sqrt2,
\qquad
K\le\sqrt2c_\ell^2<\sqrt2.
$$

On the feature side, retain only nonmonotone words over
$\{U_1,U_2,U_3\}$. Their contributions are orthogonal to every other word, so
the lower bound

$$
H_m^2\ge2^m3^{m-1}
$$

continues to hold independently of $\ell$. Consequently,

$$
\frac{2H_m}{m(m-1)M^{m-2}}
\ge
\widetilde L_m
:=
\frac{4\,3^{(m-1)/2}}{m(m-1)}.
$$

The ratio

$$
\frac{\widetilde L_{m+1}}{\widetilde L_m}
=\sqrt3\,\frac{m-1}{m+1}
$$

is below one through $m=3$ and above one from $m=4$ onward. Therefore the
minimum occurs at $m=4$ and equals
$\widetilde L_4=\sqrt3$. Since

$$
K<\sqrt2<\sqrt3
\le\inf_{m\ge2}\widetilde L_m,
$$

the coefficientwise condition holds for every chain length. Thus

$$
\boxed{
\delta_{U_1,\ldots,U_\ell}(\lambda)
<\mathcal B_{U_1,\ldots,U_\ell}(\lambda)
\quad
(\ell\ge3,\ \lambda>0).
}
$$

The bounds sum to a closed-form quantitative version:

$$
\boxed{
\delta_{U_1,\ldots,U_\ell}(\lambda)
<
\frac{\lambda^2}{\sqrt2}e^{\sqrt2\lambda}
<
\frac{e^{\sqrt6\lambda}-1-\sqrt6\lambda}{\sqrt3}
\le
\mathcal B_{U_1,\ldots,U_\ell}(\lambda).
}
$$

The first inequality uses $M,K<\sqrt2$. The last follows by summing
$H_m\ge(\sqrt6)^m/\sqrt3$. The middle inequality is coefficientwise and is
equivalent to $\sqrt2<\widetilde L_m$ for every $m\ge2$.

Merging $\ell$ such intervals into one reduces generic depth-two
log-signature storage by the factor $\ell$, while retaining a nonempty interval
of response tolerances rejected by the exact Hilbert--Schmidt certificate. The
separation margin is uniform in the chain length.

### 8.11 Spectral response-gauge bounds for degree-two blocks

The abstract gauges $M$ and $K$ admit inexpensive certified bounds for
degree-two Lie blocks. Represent such a block by a skew-symmetric matrix
$\Omega\in\mathbb R^{d\times d}$:

$$
U_\Omega=\sum_{i,j=1}^d\Omega_{ij}e_i\otimes e_j,
\qquad
R_A(U_\Omega)=\sum_{i<j}\Omega_{ij}[A_i,A_j].
$$

First, the individual response gauge is exact.

#### Proposition

For every response dimension $n\ge2$,

$$
\boxed{
\sup_{\lVert A\rVert_F\le1}
\lVert R_A(U_\Omega)\rVert_{\mathrm{op}}
=
\sup_{\lVert A\rVert_F\le1}
\lVert R_A(U_\Omega)\rVert_F
=\frac{\lVert\Omega\rVert_{\mathrm{op}}}{\sqrt2}.
}
$$

*Proof.* An orthogonal driver-coordinate change puts $\Omega$ into real skew
normal form with $2\times2$ blocks
$\sigma_j\left(\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\right)$.
Writing $b_k=\lVert B_k\rVert_F$ for the transformed response tuple,
Böttcher--Wenzel gives

$$
\lVert R_A(U_\Omega)\rVert_F
\le\sqrt2\sum_j\sigma_jb_{2j-1}b_{2j}
\le\frac{\sigma_1}{\sqrt2}\sum_kb_k^2
\le\frac{\lVert\Omega\rVert_{\mathrm{op}}}{\sqrt2}.
$$

Concentrate the coefficient budget in a top singular plane and use

$$
B=\begin{pmatrix}1/2&0\\0&-1/2\end{pmatrix},
\qquad
C=\begin{pmatrix}0&1/\sqrt2\\0&0\end{pmatrix}.
$$

Then $\lVert B\rVert_F^2+\lVert C\rVert_F^2=1$ and
$[B,C]=C$, whose operator and Frobenius norms both equal $1/\sqrt2$.
This attains both upper bounds. $\square$

Now let $\Omega^{(1)},\ldots,\Omega^{(\ell)}$ represent the blocks to merge.
Define

$$
W_{ij}=\sum_{s=1}^\ell|\Omega^{(s)}_{ij}|,
\qquad
\Lambda=\lambda_{\max}(W),
\qquad
\sigma_s=\lVert\Omega^{(s)}\rVert_{\mathrm{op}}.
$$

The matrix $W$ is a nonnegative weighted driver-overlap graph. Set

$$
\widehat M
=\frac1{\sqrt2}\min\left\{\Lambda,\sum_s\sigma_s\right\},
$$

and

$$
\widehat K
=\frac1{\sqrt2}\min\left\{
\frac{\Lambda^2}{2},
\sum_{s<t}\sigma_s\sigma_t
\right\}.
$$

#### Theorem

The multiblock response gauges of §8.9 satisfy

$$
\boxed{
M\le\widehat M,
\qquad
K\le\widehat K.
}
$$

*Proof.* Put $a_i=\lVert A_i\rVert_F$. For
$X_s=R_A(U_{\Omega^{(s)}})$, Böttcher--Wenzel and the triangle inequality give

$$
\lVert X_s\rVert_F
\le\sqrt2\sum_{i<j}|\Omega^{(s)}_{ij}|a_ia_j.
$$

Summing in $s$,

$$
\sum_s\lVert X_s\rVert_{\mathrm{op}}
\le\frac1{\sqrt2}a^\mathsf TWa
\le\frac{\Lambda}{\sqrt2}.
$$

The individual proposition also bounds this sum by
$\sum_s\sigma_s/\sqrt2$, proving the claim for $M$.

Write
$q_s=\sum_{i<j}|\Omega^{(s)}_{ij}|a_ia_j$. A second
Böttcher--Wenzel application gives

$$
\begin{aligned}
\sum_{s<t}\lVert[X_s,X_t]\rVert_{\mathrm{op}}
&\le\sqrt2\sum_{s<t}\lVert X_s\rVert_F\lVert X_t\rVert_F\\
&\le2\sqrt2\sum_{s<t}q_sq_t\\
&\le\sqrt2\left(\sum_sq_s\right)^2\\
&\le\frac{\Lambda^2}{2\sqrt2}.
\end{aligned}
$$

Alternatively, the individual bound
$\lVert X_s\rVert_F\le\sigma_s/\sqrt2$ gives
$K\le\sum_{s<t}\sigma_s\sigma_t/\sqrt2$. Taking the better of the two proves
the result. $\square$

Let $G_{st}=\langle\Omega^{(s)},\Omega^{(t)}\rangle_F$. This is exactly the
block Gram matrix required by §8.9, so each $H_m$ is feature-side computable.
For $\widehat M>0$, the sufficient condition

$$
\boxed{
\widehat K
<
\inf_{m\ge2}
\frac{2H_m(G)}{m(m-1)\widehat M^{m-2}}
}
$$

therefore certifies all-scale response separation without optimizing over a
matrix response system. The infimum ranges over infinitely many levels; a
finite scan alone verifies no all-scale claim. The chain proof supplies an
analytic lower bound for that infimum. At one fixed scale, a certificate partial
sum is a valid lower bound and can certify separation from a response upper
bound. Constructing $G$ and $W$ costs
$O(\ell^2d^2+\ell d^2)$, followed by one $d\times d$ symmetric eigenvalue
calculation. For the coordinate-loop chain, $W$ is the path adjacency matrix,
so these bounds recover exactly
$M\le\sqrt2\cos(\pi/(\ell+2))$ and
$K\le\sqrt2\cos^2(\pi/(\ell+2))$ from §8.10.

## 9. Euler storage optimization

`storage.md` contains the next application of these response constants. It
proves the exact bounded variation Euler minimax error, including optimization
over path-dependent partitions; preservation of FPL's leading asymptotics;
and a response storage sandwich on pure Engel rough paths. The latter gives
a growing storage separation from the exact HS certificate under Euler
decoding and dense generic storage. A pure path is exact under a single
log-ODE factor; that decoder defines a different optimization problem.

## 10. Planar BV and mixed displacement/area distortion

The planar BV and mixed displacement/area proofs are in
`notebooks/08_response_distance.ipynb`; `mixed_blocks.md` indexes that argument.
They use the exact degree-three gauge from §3 and positive degree-four tails
to give finite-scale and perturbation radii. This extends separation beyond
homogeneous blocks when the first cubic discrepancy is nonzero.

## References

Keys match `papers/references.bib` where present.

- Chevyrev, I. and Lyons, T. (2016). Characteristic functions of measures on
  geometric rough paths. *Ann. Probab.* 44. arXiv:1307.3580.
  §4.2 and Theorem 4.8: polynomial identities and development separation.
- Le Donne, E. (2016). A primer on Carnot groups: homogenous groups,
  Carnot--Carathéodory spaces, and regularity of their isometries.
  arXiv:1604.08579. Definition 2.1: homogeneous distances.
- Nikolaev, R. S. (1986). Identities of two variables in the Lie algebra
  $\mathfrak{sl}(2,K)$ over a field of characteristic zero. *Pliska Studia Math.
  Bulgarica* 8, 65--76 (Russian). Theorem 1, equation (1): the identity in §6.1.
- Iserles, A. and Kropielnicka, K. (2024). An elementary approach to splittings
  of unbounded operators. arXiv:2401.06635. Theorem 2.1 and §3.1: commutator
  representation and standard Lie--Trotter error bounds.
- Fox, D. J. F. (2026). Sharp commutator bounds on complex simple Lie algebras:
  the Böttcher--Wenzel inequality and the comass of the Cartan 3-form.
  arXiv:2610.11800, posted 8 October. Theorem 1.2 recovers the matrix commutator
  inequality used here; its restricted representation classes have other constants.
- Böttcher, A. and Wenzel, D. (2008). The Frobenius norm and the commutator.
  *Linear Algebra Appl.* 429, 1864--1885. Sharp constant $\sqrt2$ used in §2, §4
  and §8.
- Boedihardjo, H., Geng, X. and Souris, N. P. (2020). Path developments and tail
  asymptotics of signature for pure rough paths. *Adv. Math.* 364, 107043.
  arXiv:1811.12170. Spectral properties of Lie polynomials under development.
- Li, N. and Gao, X. (2026). Exact signature tail asymptotics for pure rough
  paths. arXiv:2606.30055. Contractive development realising a tensor norm as an
  eigenvalue; related prior art to the elementary attainment argument of §2.
- Boedihardjo, H., Geng, X. and Wang, S. (2025). Cartan's path development, the
  logarithmic signature and a conjecture of Lyons--Sidorova. arXiv:2506.18207.
- Ferrucci, E., Perrée, O. and Lyons, T. (2026). Concise $(\varepsilon,r)$
  representations of a path. arXiv:2607.26281. Norm conventions and the
  $(\varepsilon,r)$ criterion used throughout.
- Hambly, B. and Lyons, T. (2010). Uniqueness for the signature of a path of
  bounded variation. *Ann. Math.* 171, 109--167.
- Kanel-Belov, A., Malev, S. and Rowen, L. (2016). The images of Lie polynomials
  evaluated on matrices. arXiv:1506.06792. Minimal degree $m_n$ of a Lie
  identity of $\mathfrak{sl}(n)$; $m_2=5$, $m_n\le n^2+1$, general case open.
- Briët, J., Regev, O. and Saket, R. (2017). Tight hardness of the
  noncommutative Grothendieck problem. *Theory Comput.* 13. arXiv:1412.4413.
  Hardness for an adjacent matrix bilinear optimisation problem; its constraints
  differ and no reduction from $\gamma_{k,n}$ is claimed.
- Smith, R. R. (1983). Completely bounded maps between $C^*$-algebras. *J.
  London Math. Soc.* 27, 157--166. For maps into $M_n$, completely bounded norm
  equals the norm at level $n$. Possible tool after linearisation; it does not
  directly apply to the nonlinear, dimension-varying definition of
  $\gamma_{k,n}$.
- Lyons, T. and Sidorova, N. (2005). Sound compression, a rough path approach.
  Historical compression background; full original text was unavailable
  during the 14 October review.
- Moan, P. C. and Niesen, J. (2008). Convergence of the Magnus series.
  *Found. Comput. Math.* 8, 291--301. Iterated commutator estimates in the
  Magnus setting.
