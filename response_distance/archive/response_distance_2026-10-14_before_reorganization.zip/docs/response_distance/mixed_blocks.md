# Planar BV and mixed-block proof index

Consolidated 14 October 2026. The authoritative argument and executable
example are [notebook 08](../../notebooks/08_response_distance.ipynb).
The earlier detailed working copy and pre-run design remain in
[archive](archive/2026-10-14_mixed_blocks.md).

Norms: joint Frobenius coefficient budget, Euclidean operator response,
canonical Hilbert--Schmidt (HS) tensors; chronological row-state products.

## 1. First-discrepancy lemma

Full planar group-like series agreeing through degree two have a cubic Lie
difference $D_3$. Its sharp response/HS ratio is $\rho=2\sqrt2/9$ for $n\ge2$.
Uniform higher-degree tails justify the full-response limit when $D_3\ne0$.

## 2. Finite-scale separation

Positive exponential tails supply an explicit sufficient radius with response
upper bound strictly below the full HS certificate. Floating-point evaluations
are numerical; the radius is sufficient rather than maximal.

## 3. BV paths and fixed partitions

For a continuous planar BV path, compare $S(X)$ with
$\prod_i\exp_\otimes(\ell_{i,1}+\ell_{i,2})$.
Then $D_3=\sum_i\ell_{i,3}$. A nonzero sum gives the sharp limit, positive scale
radius and a BV perturbation neighborhood on a fixed common partition.
Mesh-uniformity requires a separate nondegeneracy condition.

## 4. Mixed displacement/area blocks

Two blocks with increments $v_i$ and areas $\alpha_i[e_1,e_2]$ have cubic
difference $[w,[e_1,e_2]]$, where

$$
w=\tfrac12(\alpha_2v_1-\alpha_1v_2)
+\tfrac{\det(v_1,v_2)}{12}(v_1-v_2).
$$

For independent increments, cancellation occurs exactly at
$\alpha_1=\alpha_2=-\det(v_1,v_2)/6$.
Cubic cancellation can leave quartic error; pure planar area blocks commute.

## 5. Evidence and prior work

[Findings, Study K](findings.md#study-k-planar-bv-and-mixed-blocks) owns runs;
[literature](literature.md) owns primary-source comparisons.
Independent mathematical reading and exact-ratio novelty checks remain open.

## 6. Deterministic design

Original design is preserved in the archived working copy and notebook 08.
The runner compares analytic bounds with explicit developments on eight
predefined cases, includes degeneracies, and fails if a witness exceeds its
bound or a guaranteed-radius gap disappears. It uses no ascent.
